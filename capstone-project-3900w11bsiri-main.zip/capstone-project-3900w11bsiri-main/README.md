Siri has uploaded their software quality zip file on time, before the deadline.
Link to Siri GitHub repository: https://github.com/unsw-cse-comp3900-9900-23T2/capstone-project-3900w11bsiri

# Installation Manual
Our front and backend are hosted on a server using Vultr, and because of this our app can be accessed via the domain “www.delcan.xyz” (on mobile or desktop).
In case this doesn’t work for whatever reason, the following instructions can be used to set up the application locally.

## Back-end Setup:
1. Download the latest version of Python from the official website (https://www.python.org/downloads/).
2. Install pip3, a package installer for Python, if it's not already installed with Python. You can verify if pip3 is installed by typing `pip3 --version` in your terminal.
3. Install additional Python dependencies listed in the requirements.txt file with this pip3 command: `pip3 install -r requirements.txt`.
4. Login to MongoDB Atlas to add your IP for the backend to connect to the database. Use the following credentials: Username: z5311976@ad.unsw.edu.au and Password: siri2023
5. Run the Django server with this command: `python3 manage.py runserver`.

## Front-end Setup:
1. Install Node.js and npm. You can download them from https://nodejs.org/en/download/current. Choose the version that suits your operating system.
2. Navigate to the `frontend-setup` directory in the terminal.
3. Make sure that your package.json file includes the necessary dependencies listed in the provided package.json text.
4. Install the dependencies listed in the package.json file with this command: `npm install`.
5. Start the frontend server with this command: `npm start`.
