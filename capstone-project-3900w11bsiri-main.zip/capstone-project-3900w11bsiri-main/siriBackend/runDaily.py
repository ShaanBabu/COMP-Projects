from backendApp.Logic.notifications import _sendDeadlineNotifications

# This python script is run from the runDaily.sh shell script.
# It calls the _sendDeadlineNotifications() function from backendApp/Logic/notifications.py

def main():
    _sendDeadlineNotifications()

if __name__ == "__main__":
    main()