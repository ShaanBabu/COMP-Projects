#!/bin/bash
# This script is called every day at 10am using cron
# It loads the virtual environment needed, and then runs the python script runDaily.py
source /virtual-project/bin/activate
python3 /var/www/capstone-project-3900w11bsiri/siriBackend/runDaily.py