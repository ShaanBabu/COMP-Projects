from django.apps import AppConfig
from django.forms import ValidationError
from . import database
from .Documents.User import UserModel

class BackendappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'backendApp'

    def ready(self):
        mongoConnection = database.MongoConnection.getInstance()
        client = mongoConnection.getClient()
        try:
            client.admin.command('ping')
            print("Pinged your deployment. You successfully connected to MongoDB!")
        except Exception as e:
            print(e)
            raise e  # If you want to stop the server startup when MongoDB is not accessible