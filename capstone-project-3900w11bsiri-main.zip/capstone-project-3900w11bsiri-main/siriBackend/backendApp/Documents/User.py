from pydantic import BaseModel, Field, EmailStr
from typing import List, Optional
from datetime import date

class UserModel(BaseModel):
    username: str = Field(..., title="The unique username of the user")
    password: str = Field(..., title="The hashed password of the user")
    email: str = Field(..., title="The email address of the user")
    name: str = Field(..., title="The full name of the user")
    description: str = Field('', title="The user's self-made description")
    notifications: List[str] = Field([], title="Notifications for the user")
    notification_settings: dict = Field(..., title="The user's notifications settings")
    title: Optional[str] = Field('', title="The user's title")
    birthday: date = Field('', title="The user's birthday")
    projects: List[str] = Field([], title="The list of project ids associated with the user")
    tasks: List[str] = Field([], title="The list of task ids associated with the user")
    visible: bool = Field(True, title="The profile visibility of the user")
