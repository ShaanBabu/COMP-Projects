from pydantic import BaseModel, Field
from typing import List

class NetworkModel(BaseModel):
    username: str = Field(..., title="The unique username of the user")
    friends: List[str] = Field(..., title="List of usernames of friends")
    friend_requests: List[str] = Field(..., title="List of usernames of people who have sent friend requests")
    project_requests: List[str] = Field(..., title="List of project object_ids from projects that have invited them")
