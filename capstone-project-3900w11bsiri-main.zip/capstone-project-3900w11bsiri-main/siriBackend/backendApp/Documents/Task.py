from pydantic import BaseModel, Field
from datetime import datetime
from typing import List

class TaskModel(BaseModel):
    name: str = Field(..., title="The name of the task")
    description: str = Field(..., title="The description of the task")
    due_date: datetime = Field(..., title="The due date of the task")
    assigned_to: List[str] = Field(..., title="The dictionary of assigned user's usernames")
    project: str = Field(..., title="The id of the project the task belongs to")
    status: str = Field(..., title="Status of the task. Can be 'TO DO', 'IN PROGRESS' or 'DONE'")
    comments: List[dict] = Field([], title="List of comments on the task")
    attachments: List[str] = Field([], title="List of attachment IDs for the task")
    subtasks: List[dict] = Field([], title="List of subtasks on the task")
    followers: List[str] = Field([], title="List of usernames following the task")
    reviews: List[dict] = Field([], title="List of reviews on the task") 
