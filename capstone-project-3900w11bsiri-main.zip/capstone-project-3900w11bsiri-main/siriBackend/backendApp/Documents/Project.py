from pydantic import BaseModel, Field
from datetime import datetime
from typing import Dict, List

class ProjectModel(BaseModel):
    creator: str = Field(..., title="The creator of the project")
    name: str = Field(..., title="The name of the project")
    description: str = Field(..., title="The description of the project")
    admins: List[str] = Field(..., title="The list of admin usernames")
    users: List[str] = Field([], title="The list of usernames")
    viewers: List[str] = Field([], title="The list of viewers")
    tasks: List[str] = Field([], title="The list of task IDs associated with the project")