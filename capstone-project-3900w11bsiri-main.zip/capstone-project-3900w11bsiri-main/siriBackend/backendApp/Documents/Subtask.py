from pydantic import BaseModel, Field
from datetime import datetime
from typing import List

class SubtaskModel(BaseModel):
    name: str = Field(..., title="The name of the subtask")
    description: str = Field(..., title="The description of the subtask")
    due_date: datetime = Field(..., title="The due date of the subtask")
    checked: bool = Field(..., title="The checked box of the subtask")