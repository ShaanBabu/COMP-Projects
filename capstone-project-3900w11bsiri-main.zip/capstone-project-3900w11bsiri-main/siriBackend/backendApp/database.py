import gridfs
import pymongo
from pymongo.mongo_client import MongoClient
from pymongo.server_api import ServerApi
from django.forms import ValidationError
from .Documents.User import UserModel
from .Documents.Network import NetworkModel
from .Documents.Task import TaskModel
from .Documents.Network import NetworkModel
from bson.objectid import ObjectId

class MongoConnection:
    _instance = None
    _client = None

    @staticmethod
    def getInstance():
        if MongoConnection._instance is None:
            MongoConnection._instance = MongoConnection()
        return MongoConnection._instance
    
    @staticmethod
    def getDatabase():
        if MongoConnection._instance is None:
            MongoConnection._instance = MongoConnection()
        
        return MongoConnection._client['taskmanager'] 

    def __init__(self):
        if MongoConnection._client is None:
            uri = "mongodb+srv://tyrone:zbCe84OdrZyosmjY@taskmanager.2lzrjfi.mongodb.net/?retryWrites=true&w=majority"
            MongoConnection._client = MongoClient(uri, server_api=ServerApi('1'))
    
    def getClient(self):
        return MongoConnection._client

# Database Functions

def File():
    db = MongoConnection.getDatabase()
    return gridfs.GridFS(db)

def Add(collection: str, model) -> str:
    """
    Inserts a new document into the specified MongoDB collection.
    
    Args:
        collection (str): The name of the MongoDB collection to add the document to.
        model: A Pydantic model instance containing the data to be inserted into the collection.

    Returns:
        InsertOneResult: The result of the insert operation.

    Raises:
        ValidationError: If the data in the model is not valid.
    """
    db = MongoConnection.getDatabase()
    collect = db[collection]
    try:
        return str(collect.insert_one(model.dict()).inserted_id)
    except ValidationError as e:
        print(e)


def Delete(collection: str, id: str):
    """
    Deletes a document from the specified MongoDB collection.
    
    Args:
        collection (str): The name of the MongoDB collection to delete the document from.
        id (str): The id of the document to delete.
    
    Raises:
    ValidationError: If the data in the model is not valid.
    """

    
    db = MongoConnection.getDatabase()
    collect = db[collection]
    try:
        collect.delete_one({"_id": ObjectId(id)})
    except ValidationError as e:
        print(e)

def RetrieveUser(username: str) -> dict:
    """
    Retrieves a user document from the "User" collection in MongoDB.
    
    Args:
        username (str): The username of the user to retrieve.

    Returns:
        dict: The retrieved user document, or None if no document was found.
    """
    db = MongoConnection.getDatabase()
    collect = db["Users"]
    query = { "username": username }
    return collect.find_one(query)

def UpdateUser(user: dict):
    db = MongoConnection.getDatabase()
    collect = db["Users"]
    collect.replace_one({"_id": user["_id"]}, user)

def databaseUpdate(collection: str, filter: dict, updates: dict):
    """
    Updates a document in the specified MongoDB collection.
    
    Args:
        collection (str): The name of the MongoDB collection to update the document in.
        filter (dict): The filter to select the document to update.
        updates (dict): The modifications to apply to the document.

    Returns:
        UpdateResult: The result of the update operation.
    """
    db = MongoConnection.getDatabase()
    collect = db[collection]
    return collect.update_one(filter, {'$set': updates})

def RetrieveProjects(projectIds: list[str] = None) -> list[dict]:
    db = MongoConnection.getDatabase()
    collect = db["Projects"]
    if projectIds is None:
        cursor = collect.find()
    else:
        ids = [ObjectId(id) for id in projectIds]
        cursor = collect.find({"_id": {"$in": ids}})
    return [doc for doc in cursor]

def RetrieveUserProjects(username: str) -> list[dict]:
    db = MongoConnection.getDatabase()
    collect = db["Users"]
    user = collect.find_one({"username": username})

    if user and "projects" in user:
        project_ids = user["projects"]
        return RetrieveProjects(project_ids)

    return []

def UpdateProject(project: dict):
    db = MongoConnection.getDatabase()
    collect = db["Projects"]
    collect.replace_one({"_id": project["_id"]}, project)

def RetrieveNetwork(username: str) -> dict:
    db = MongoConnection.getDatabase()
    collect = db["Networks"]
    return collect.find_one({"username": username})

def UpdateNetwork(network: dict):
    db = MongoConnection.getDatabase()
    collect = db["Networks"]
    collect.replace_one({"_id": network["_id"]}, network)

def RetrieveTasks(taskIds: list[str] = None) -> list[dict]:
    db = MongoConnection.getDatabase()
    collect = db["Tasks"]
    if taskIds is None:
        cursor = collect.find()
    else:
        ids = [ObjectId(id) for id in taskIds]
        cursor = collect.find({"_id": {"$in": ids}})
    return [doc for doc in cursor]

def UpdateTask(task: dict):
    db = MongoConnection.getDatabase()
    collect = db["Tasks"]
    collect.replace_one({"_id": task["_id"]}, task)



def RetrieveSubTasks(taskIds: list[str] = None) -> list[dict]:
    db = MongoConnection.getDatabase()
    collect = db["Subtasks"]
    if taskIds is None:
        cursor = collect.find()
    else:
        ids = [ObjectId(id) for id in taskIds]
        cursor = collect.find({"_id": {"$in": ids}})
    return [doc for doc in cursor]

def UpdateSubTask(task: dict):
    db = MongoConnection.getDatabase()
    collect = db["Subtasks"]
    collect.replace_one({"_id": task["_id"]}, task)