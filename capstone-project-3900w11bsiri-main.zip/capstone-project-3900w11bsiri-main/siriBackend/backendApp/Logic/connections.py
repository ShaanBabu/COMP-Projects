import json
from django.http import JsonResponse
from .helpers import _check_token_authentication, _get_username_from_token
from .notifications import _sendFriendRequestNotification, _sendFriendAcceptNotification, _sendFriendRejectNotification
from .. import database

### INPUTS
# token (of connection sender)
# username (of connection receiver)
### OUTPUTS
# ---
def connectUsers(request):
    requestInfo = json.loads(request.body)
    if _check_token_authentication(requestInfo['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)
    username = _get_username_from_token(requestInfo['token'])

    network1 = database.RetrieveNetwork(username)
    if network1 is None:
        return JsonResponse({'error': 'Invalid User'}, status=404)
    if requestInfo['username'] in network1['friends']:
        return JsonResponse({'error': 'Users are already connected'}, status=400)
    if requestInfo['username'] in network1['friend_requests']:
        return JsonResponse({'error': 'Sending user has pending request'}, status=400)
    if username == requestInfo['username']:
        return JsonResponse({'error': 'Cannot send request to self'}, status=400)
    
    network2 = database.RetrieveNetwork(requestInfo['username'])
    if network2 is None:
        return JsonResponse({'error': 'This user does not exist'}, status=404)
    if username in network2['friend_requests']:
        return JsonResponse({'error': 'User had already requested a connection'}, status=400)
    
    user2 = database.RetrieveUser(requestInfo['username'])
    if user2['visible'] == False:
        return JsonResponse({'error': 'This person\'s visibility is set to private'}, status=400)
    
    network2['friend_requests'].append(username)
    database.UpdateNetwork(network2)
    
    _sendFriendRequestNotification(username, requestInfo['username'])

    return JsonResponse({'message': 'Connection request added successfully'}, status=200)

### INPUTS
# token (of user receiving request)
# username (of request sender)
# accept (boolean indicating whether request should be accepted)
### OUTPUTS
# ---
def handleConnectionRequest(request):
    # user1 is accepting or denying request from user2
    requestInfo = json.loads(request.body)
    if _check_token_authentication(requestInfo['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)
    username = _get_username_from_token(requestInfo['token'])
    
    network1 = database.RetrieveNetwork(username)
    if network1 is None:
        return JsonResponse({'error': 'Invalid User'}, status=404)
    if requestInfo['username'] not in network1['friend_requests']:
        return JsonResponse({'error': 'User does not have pending connection request'}, status=400)
    
    network2 = database.RetrieveNetwork(requestInfo['username'])
    if network2 is None:
        return JsonResponse({'error': 'Invalid User'}, status=404)

    user1 = database.RetrieveUser(username)
    user2 = database.RetrieveUser(requestInfo['username'])

    if requestInfo['accept'] == True:
        network1['friend_requests'].remove(requestInfo['username'])

        network1['friends'].append(requestInfo['username'])
        network2['friends'].append(username)

        database.UpdateNetwork(network1)
        database.UpdateNetwork(network2)
        _sendFriendAcceptNotification(username, requestInfo['username'])

        return JsonResponse({'message': 'Connection added successfully'}, status=200)
    else:
        network1['friend_requests'].remove(requestInfo['username'])

        database.UpdateNetwork(network1)
        _sendFriendRejectNotification(username, requestInfo['username'])

        return JsonResponse({'message': 'Connection declined successfully'}, status=200)

### INPUTS
# token
### OUTPUTS
# connections (list of usernames)
# connectionRequests (list of usernames)
# projectInvites (list of project object_ids)
def displayConnections(request):
    data = json.loads(request.body)

    if _check_token_authentication(data['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)

    username = _get_username_from_token(data['token'])

    network = database.RetrieveNetwork(username)
    return JsonResponse({
        "connections": network['friends'],
        "connectionRequests": network['friend_requests'],
        "projectInvites": network['project_requests']
    }, safe=False)