import jwt
from .. import database

def _check_token_authentication(token):
    try:
        data = jwt.decode(token, 'SECRET', algorithms='HS256')
        return data
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None


def _get_username_from_token(token):
    try:
        decoded_data = jwt.decode(token, 'SECRET', algorithms='HS256')
        return decoded_data['token']['username']
    except jwt.InvalidTokenError:
        return None
    
def _can_edit_task(username: str, taskId: str) -> bool:
    task = database.RetrieveTasks([taskId])[0]
    project = database.RetrieveProjects([task['project']])[0]
    if task is None:
        return False
    return username in task['assigned_to'] or username in project['admins']