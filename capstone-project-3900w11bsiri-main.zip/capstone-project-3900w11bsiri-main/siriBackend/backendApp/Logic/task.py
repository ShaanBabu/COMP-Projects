import json
from bson import ObjectId
from django.http import JsonResponse, FileResponse, HttpResponse
from .helpers import _check_token_authentication, _get_username_from_token, _can_edit_task
from .notifications import _sendTaskAssignNotification, _sendTaskStatusNotification, _sendPingNotification
from .. import database
from ..Documents.Task import TaskModel
from ..Documents.Subtask import SubtaskModel
from datetime import datetime

### INPUTS
# token
# name (of task)
# description
# due_date
# assigned_to
# projectID
# status
### OUTPUTS
# taskId
def createTask(request):
    taskInfo = json.loads(request.body)

    if _check_token_authentication(taskInfo['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)

    assigner = _get_username_from_token(taskInfo['token'])  # Get the username of the assigner

    project = database.RetrieveProjects([taskInfo['projectID']])[0]
    if project is None:
        return JsonResponse({'error': 'Invalid Project'}, status=404)
    if assigner not in project['users']:
        return JsonResponse({'error': 'User does not have permission to create task'}, status=403)

    if len(taskInfo['assigned_to']) == 0:
        taskInfo['assigned_to'].append(assigner)

    try:
        datetime.fromisoformat(taskInfo['due_date'])
    except ValueError:
        return JsonResponse({'error': 'Invalid due date given'}, status=400)

    task = TaskModel(
        name = taskInfo['name'],
        description = taskInfo['description'],
        due_date = datetime.fromisoformat(taskInfo['due_date']),
        assigned_to = taskInfo['assigned_to'],
        project = taskInfo['projectID'],
        status = taskInfo['status'],
    )

    taskId = database.Add("Tasks", task)

    for user in taskInfo['assigned_to']:
        _sendTaskAssignNotification(assigner, user, taskId)

    # Add the task to the respective project
    project = database.RetrieveProjects([taskInfo['projectID']])[0]
    project["tasks"].append(taskId)
    database.UpdateProject(project)

    # Add the task to each assigned user's task list
    for assigned_user in taskInfo['assigned_to']:
        user = database.RetrieveUser(assigned_user)
        user["tasks"].append(taskId)
        database.UpdateUser(user)

    return JsonResponse({'message': 'Created task', 'taskId': taskId}, status=200)

### INPUTS
# token
# taskId
# name (optional)
# description (optional)
# due_date (optional)
# status (optional)
# assigned_to (optional)
### OUTPUTS
# ---
def editTask(request):
    data = json.loads(request.body)

    if _check_token_authentication(data['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)

    editor = _get_username_from_token(data['token'])
    tasks = database.RetrieveTasks([data['taskId']])
    if not tasks:
        return JsonResponse({'error': 'Task not found'}, status=404)

    task = tasks[0]
    if not _can_edit_task(editor, data['taskId']):
        return JsonResponse({'error': 'User does not have permission to modify this task'}, status=403)

    if 'name' in data:
        task['name'] = data['name']
    if 'description' in data:
        task['description'] = data['description']
    if 'due_date' in data:
        task['due_date'] = datetime.fromisoformat(data['due_date'])
    if 'status' in data and task['status'] != data['status']:
        for user in task['followers']:
            _sendTaskStatusNotification(data['taskId'], task['status'], data['status'], user)
        task['status'] = data['status']
    if 'assigned_to' in data:
        new_assigned_users = data['assigned_to']
        old_assigned_users = task['assigned_to']

        for user in old_assigned_users:
            if user not in new_assigned_users:
                user_obj = database.RetrieveUser(user)
                if user_obj is not None and data['taskId'] in user_obj['tasks']:
                    user_obj['tasks'].remove(data['taskId'])
                    database.UpdateUser(user_obj)

        for user in new_assigned_users:
            if user not in old_assigned_users:
                user_obj = database.RetrieveUser(user)
                if user_obj is not None and data['taskId'] not in user_obj['tasks']:
                    user_obj['tasks'].append(data['taskId'])
                    database.UpdateUser(user_obj)
                _sendTaskAssignNotification(editor, user, data['taskId'])
        
        task['assigned_to'] = new_assigned_users

    database.UpdateTask(task)
    return JsonResponse({'message': 'Task updated successfully'}, status=200)

### INPUTS
# token
# projectID
### OUTPUTS
# tasks (list of tasks)
def displayProjectTasks(request):
    data = json.loads(request.body)

    if _check_token_authentication(data['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)

    project_id = data['projectID']
    project = database.RetrieveProjects([project_id])[0]
    if project is None:
        return JsonResponse({'error': 'Invalid Project'}, status=404)

    tasks = database.RetrieveTasks(project['tasks'])

    for task in tasks:
        task['_id'] = str(task['_id'])
        task["comments"] = task.get("comments", [])

        subtask_ids = task.get("subtasks", [])
        subtasks = database.RetrieveSubTasks(subtask_ids)
        for subtask in subtasks:
            subtask['_id'] = str(subtask['_id']) 

        task["subtasks"] = subtasks
        # Retrieve the list of file IDs attached to the task
        file_ids = task.get("attachments", [])
        
        # Fetch the file information from MongoDB GridFS
        files = []
        for file_id in file_ids:
            file_data = database.File().get(file_id['file_id'])
            file_info = {
                "file_id": str(file_id['file_id']),
                "filename": file_data.filename,
                "user": file_id['username'],
            }
            files.append(file_info)
        task["attachments"] = files
    return JsonResponse({'tasks': tasks}, status=200)
### INPUTS
# token
# taskId
# comment
# pings (optional list of usernames)
### OUTPUTS
# ---
def addCommentToTask(request):
    data = json.loads(request.body)

    if _check_token_authentication(data['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)

    commenter = _get_username_from_token(data['token'])
    tasks = database.RetrieveTasks([data['taskId']])
    if not tasks:
        return JsonResponse({'error': 'Task not found'}, status=404)

    task = tasks[0]
    # only assigned users and task creator can comment on the task
    if commenter not in task['assigned_to']:
        return JsonResponse({'error': 'User does not have permission to comment on this task'}, status=403)

    comment = {
        'username': commenter,
        'comment': data['comment'],
    }
    
    task['comments'].append(comment)

    database.UpdateTask(task)

    if 'pings' in data:
        for ping in data['pings']:
            _sendPingNotification(commenter, ping, data['taskId'], data['comment'])

    return JsonResponse({'message': 'Comment added successfully'}, status=200)


### INPUTS
# token
# taskId
### OUTPUTS
# ---
def removeTask(request):
    data = json.loads(request.body)

    if _check_token_authentication(data['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)

    tasks = database.RetrieveTasks([data['taskId']])
    if not tasks:
        return JsonResponse({'error': 'Task not found'}, status=404)

    _removeTask(data['taskId'])

    return JsonResponse({'message': 'Removed task', 'taskId': data['taskId']}, status=200)

def _removeTask(taskId):
    tasks = database.RetrieveTasks([taskId])
    if not tasks:
        return JsonResponse({'error': 'Task not found'}, status=404)

    task = tasks[0]

    # Remove the task from the respective project
    project = database.RetrieveProjects([task['project']])[0]
    project["tasks"].remove(taskId)
    database.UpdateProject(project)

    # Remove the task from each assigned user's task list
    for assigned_user in task['assigned_to']:
        user = database.RetrieveUser(assigned_user)
        user["tasks"].remove(taskId)
        database.UpdateUser(user)

    database.Delete("Tasks", taskId)


### INPUTS
# token
# taskId
# status
### OUTPUTS
# ---
def updateTaskStatus(request):
# Parse the request body for necessary information
    data = json.loads(request.body)

    # Check if token is valid
    if _check_token_authentication(data['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)

    # Get the username from the token
    username = _get_username_from_token(data['token'])
    
    tasks = database.RetrieveTasks([data['taskId']])
    if not tasks:
        return JsonResponse({'error': 'Task not found'}, status=404)

    task = tasks[0]

    # Check if the user is assigned to the task
    if username not in task['assigned_to']:
        return JsonResponse({'error': 'User not assigned to this task'}, status=403)

    # Update the status of the task
    if data['status'] in ['NOT STARTED', 'IN PROGRESS', 'BLOCKED', 'COMPLETED']:
        task['status'] = data['status']
        database.UpdateTask(task)
        return JsonResponse({'message': f'Successfully updated task status'}, status=200)
    else:
        return JsonResponse({'error': 'Invalid status'}, status=400)


### INPUTS
# token
# taskId
# file (in form-data)
### OUTPUTS
# ---
def attachFile(request):
    if request.method == 'POST':
        token = request.POST.get('token')
        if _check_token_authentication(token) is None:
            return JsonResponse({'error': 'Invalid or expired token'}, status=401)
        
        username = _get_username_from_token(token)
        task_id = request.POST.get('taskId')
        tasks = database.RetrieveTasks([task_id])
        if not tasks:
            return JsonResponse({'error': 'Task not found'}, status=404)
        
        task = tasks[0]
        
        if username not in task['assigned_to'] and username:
            return JsonResponse({'error': 'User does not have permission to modify this task'}, status=403)
        
        if 'file' in request.FILES:
            file_data = request.FILES['file']

            file_id = database.File().put(file_data, filename=file_data.name)

            # Attach the file_id to the task with user 
            attachment = {
                'file_id': file_id,
                'username': username
            }
            task['attachments'].append(attachment)
            database.UpdateTask(task)
            
            return JsonResponse({'message': 'File attached successfully', 'file_id': str(file_id)}, status=200)
        
        else:
            return JsonResponse({'error': 'No file found in request'}, status=400)
    else:
        return JsonResponse({'error': 'Invalid request'}, status=400)



### INPUTS
# file_id
### OUTPUTS
# the file
def downloadFile(request):
    file_id = request.GET.get('file_id')
    file_id_obj = ObjectId(file_id)
    file_data = database.File().get(file_id_obj)
    # Check if the file data is None
    if file_data is None:
        return JsonResponse({'error': 'File not found'}, status=404)
    response = FileResponse(file_data, as_attachment=True)

    return response


### INPUTS
# token
# taskId
# file_id
### OUTPUTS
# the file
def deleteFile(request):
    data = json.loads(request.body)
    if _check_token_authentication(data['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)

    username = _get_username_from_token(data['token'])
    tasks = database.RetrieveTasks([data['taskId']])
    if not tasks:
        return JsonResponse({'error': 'Task not found'}, status=404)

    task = tasks[0]

    if username not in task['assigned_to']:
        return JsonResponse({'error': 'User does not have permission to delete this file'}, status=403)

    # Remove the file from the task's attachments
    task['attachments'] = [att for att in task['attachments'] if str(att['file_id']) != str(data['file_id'])]
    database.UpdateTask(task)

    # Delete the file from GridFS
    database.File().delete(ObjectId(data['file_id']))


    return JsonResponse({'message': 'File deleted successfully'}, status=200)

### INPUTS
# token
# taskID
### OUTPUTS
# ---
def followTask(request):
    info = json.loads(request.body)
    if _check_token_authentication(info['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)
    follower = _get_username_from_token(info['token'])

    task = database.RetrieveTasks([info['taskID']])[0]
    project = database.RetrieveProjects([task['project']])[0]

    if follower not in project['viewers']:
        return JsonResponse({'error': 'User does not have permission to follow task'}, status=403)
    
    if follower not in task['followers']:
        task['followers'].append(follower)
    database.UpdateTask(task)
    
    return JsonResponse({'message': 'User is following task'}, status=200)

### INPUTS
# token
# taskID
### OUTPUTS
# ---
def unfollowTask(request):
    info = json.loads(request.body)
    if _check_token_authentication(info['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)
    follower = _get_username_from_token(info['token'])

    task = database.RetrieveTasks([info['taskID']])[0]
    
    if follower in task['followers']:
        task['followers'].remove(follower)
    database.UpdateTask(task)
    
    return JsonResponse({'message': 'User is not following task'}, status=200)

### INPUTS
# token
# taskID
# name
# description
# due date
### OUTPUTS
# ---
def createSubtask(request):
    taskInfo = json.loads(request.body)
    if _check_token_authentication(taskInfo['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)
    assigner = _get_username_from_token(taskInfo['token'])  # Get the username of the assigner

    # Retrieve the task
    task = database.RetrieveTasks([taskInfo['taskID']])
    if not task:
        return JsonResponse({'error': 'Invalid Task'}, status=404)
    task = task[0]

    # Check if the assigner has permission
    if assigner not in task['assigned_to']:
        return JsonResponse({'error': 'User does not have permission to create subtask'}, status=403)

    subtask = SubtaskModel(
        name = taskInfo['name'],
        description = taskInfo['description'],
        due_date = datetime.fromisoformat(taskInfo['due_date']),
        task = taskInfo['taskID'],
        checked = False,
    )

    subtaskId = database.Add("Subtasks", subtask)

    # Add the subtask to the respective task
    task["subtasks"].append(subtaskId)
    database.UpdateTask(task)

    return JsonResponse({'message': 'Created subtask', 'taskId': subtaskId}, status=200)


### INPUTS
# token
# subtaskID
### OUTPUTS
# ---
def checkSubtask(request):
    taskInfo = json.loads(request.body)
    if _check_token_authentication(taskInfo['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)
    subtask = database.RetrieveSubTasks([taskInfo['subtaskID']])[0]
    subtask['checked'] = taskInfo['checked']
    database.UpdateSubTask(subtask)
    return JsonResponse({'message': 'Successfully updated task status'}, status=200)




### Add reviews, use checks to see if user is in task and if task is finished
def addReview(request):
    data = json.loads(request.body)
    if _check_token_authentication(data['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)
    reviewer = _get_username_from_token(data['token'])
    reviewee = database.RetrieveUser(data['reviewedUser'])
    tasks = database.RetrieveTasks([data['taskId']])
    if not tasks:
        return JsonResponse({'error': 'Task not found'}, status=404)
    task = tasks[0]
    review = {
        'reviewer': reviewer,
        'reviewedUsers': reviewee['username'],
        'review': data['review'],
        'rating': data['rating'],  # added this line
    }

    task['reviews'].append(review)

    database.UpdateTask(task)
    return JsonResponse({'message': 'Successfully added review'}, status=200)

#### Display reviews

def displayReviews(request):
    data = json.loads(request.body)
    if _check_token_authentication(data['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)

    # Get the project by ID
    project = database.RetrieveProjects([data['projectId']])
    if not project:
        return JsonResponse({'error': 'project not found'}, status=404)

    project = project[0]

    # Get the task IDs from the project
    task_ids = project['tasks']

    # Gather the reviews from each task
    reviews = []
    for task_id in task_ids:
        task = database.RetrieveTasks([task_id])
        if task:
            task = task[0]
            reviews.extend(task['reviews'])
    return JsonResponse({'reviews': reviews}, status=200)
