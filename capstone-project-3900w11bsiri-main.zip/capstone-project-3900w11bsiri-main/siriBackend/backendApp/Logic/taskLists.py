import json
from django.http import JsonResponse
from .helpers import _check_token_authentication, _get_username_from_token
from .. import database

### INPUTS
# token
# username (of task list owner - optional)
### OUTPUTS
# list of tasks
# tasks contain:
# name
# description
# due_date
# assigned_to (list of usernames)
# project
# status
def viewTaskList(request):
    requestInfo = json.loads(request.body)
    if _check_token_authentication(requestInfo['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)
    username = _get_username_from_token(requestInfo['token'])

    if 'username' not in requestInfo or requestInfo['username'] == username:
        user = database.RetrieveUser(username)
        if user is None:
            return JsonResponse({'error': 'Invalid User'}, status=404)
        
        tasks = database.RetrieveTasks(user['tasks'])
        for task in tasks:
            task['_id'] = str(task['_id'])
            task['project_name'] = database.RetrieveProjects([task['project']])[0]['name']
            for attachment in task['attachments']:
                attachment['file_id'] = str(attachment['file_id'])
        return JsonResponse(tasks, safe=False)
    else:
        network = database.RetrieveNetwork(username)
        if network is None:
            return JsonResponse({'error': 'Invalid User'}, status=404)
        if requestInfo['username'] not in network['friends']:
            return JsonResponse({'error': 'User is not a connection'})
        user = database.RetrieveUser(requestInfo['username'])
        if user is None:
            return JsonResponse({'error': 'Invalid User'}, status=404)
        
        tasks = database.RetrieveTasks(user['tasks'])
        for task in tasks:
            task['_id'] = str(task['_id'])
            task['project_name'] = database.RetrieveProjects([task['project']])[0]['name']
            for attachment in task['attachments']:
                attachment['file_id'] = str(attachment['file_id'])
        return JsonResponse(tasks, safe=False)

