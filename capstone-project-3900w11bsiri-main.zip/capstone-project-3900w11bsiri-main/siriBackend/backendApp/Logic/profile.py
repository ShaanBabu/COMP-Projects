import json
from django.http import JsonResponse
from .helpers import _check_token_authentication, _get_username_from_token
from .. import database

### INPUTS
# token (of viewer)
# username (of profile)
### OUTPUTS if friend:
# username
# email
# name
# title
# birthday
# projects (list of project ids)
# tasks (list of task ids)
# is_friend (boolean of whether the viewer is a friend of the profile user)
### OUTPUTS if not friend
# username
# is_friend (boolean of whether the viewer is a friend of the profile user)
def profileUser(request):
    data = json.loads(request.body)
    if _check_token_authentication(data['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)

    viewer_username = _get_username_from_token(data['token'])  
    profile_username = data['username']  

    profile_network = database.RetrieveNetwork(profile_username)
    if profile_network is None:
        return JsonResponse({'error': 'Invalid User'}, status=404)

    is_friend = viewer_username in profile_network['friends']

    user = database.RetrieveUser(profile_username)
    if user is None:
        return JsonResponse({'error': 'Invalid User'}, status=404)

    if is_friend:
        project_list = database.RetrieveProjects(user['projects'])
        project_names = [project['name'] for project in project_list]
        
        response_data = {
            'username': user['username'],
            'email': user['email'],
            'name': user['name'],
            'title': user.get('title'),
            'birthday': user.get('birthday'),
            'projects': project_names,
            'tasks': user['tasks'],
            'is_friend': True
        }
    else:
        response_data = {
            'username': user['username'],
            'is_friend': False
        }

    return JsonResponse(response_data, status=200)

### INPUTS
# token
# email (optional)
# name (optional)
# title (optional)
# birthday (optional)
### OUTPUTS
# ---
##input any field in userModel, no output
def updateProfile(request):
    update_data = json.loads(request.body)
    token_data = _check_token_authentication(update_data.get('token'))
    
    if token_data is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)

    username = token_data.get('token').get('username')
    if not username:
        return JsonResponse({'error': 'No username in token'}, status=401)

    user = database.RetrieveUser(username)
    if user is None:
        return JsonResponse({'error': 'Invalid User'}, status=404)

    # update fields if they are present in the request
    if 'email' in update_data:
        user['email'] = update_data['email']
    if 'name' in update_data:
        user['name'] = update_data['name']
    if 'title' in update_data:
        user['title'] = update_data['title']
    if 'birthday' in update_data:
        user['birthday'] = update_data['birthday']
    if 'description' in update_data:
        user['description'] = update_data['description']
    
    # update user in database
    database.UpdateUser(user)

    return JsonResponse({'message': 'Profile updated successfully'}, status=200)

### INPUTS
# token
# visible (boolean value indicating whether profile should be visible)
### OUTPUTS
# ---
def updateVisibility(request):
    data = json.loads(request.body)
    token_data = _check_token_authentication(data.get('token'))
    
    if token_data is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)

    username = token_data.get('token').get('username')
    if not username:
        return JsonResponse({'error': 'No username in token'}, status=401)

    user = database.RetrieveUser(username)
    if user is None:
        return JsonResponse({'error': 'Invalid User'}, status=404)

    if 'visible' in data:
        user['visible'] = data['visible']
    else:
        return JsonResponse({'error': 'No visibility status provided'}, status=400)

    database.UpdateUser(user)

    return JsonResponse({'message': 'Visibility updated successfully'}, status=200)

### INPUTS
# token
### OUTPUTS
# username
# password
# email
# name
# notifications (list of strings)
# title
# birthday
# projects (list of project ids)
# tasks (list of task ids)
# visible (boolean indicating profile searchability)
##input token, outputs dictionary of usermodel
def displayProfile(request):
    data = json.loads(request.body)
    token_data = _check_token_authentication(data.get('token'))

    if token_data is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)

    username = token_data.get('token').get('username')
    if not username:
        return JsonResponse({'error': 'No username in token'}, status=401)

    user = database.RetrieveUser(username)
    if user is None:
        return JsonResponse({'error': 'Invalid User'}, status=404)

    user['_id'] = str(user['_id'])
    del user['password']

    return JsonResponse(user, safe=False)