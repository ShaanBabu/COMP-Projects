import json
from django.http import JsonResponse
from .helpers import _check_token_authentication, _get_username_from_token
from .. import database
from ..Documents.Project import ProjectModel
from .task import _removeTask
from .notifications import _sendProjectInviteNotification

### INPUTS
# token
### OUTPUTS
# list of projects
# projects contain:
# creator (username)
# name
# description
# admins (list of usernames)
# users (list of usernames)
# tasks (list of task ids)
def displayProjects(request):
    data = json.loads(request.body)

    if _check_token_authentication(data['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)

    username = _get_username_from_token(data['token'])
    
    user_projects = database.RetrieveUserProjects(username)
    
    for project in user_projects:
        project['_id'] = str(project['_id'])

    return JsonResponse(user_projects, safe=False)
    
### INPUTS
# token
# name
# description
### OUTPUTS
# projectID
def createProject(request):
    projectInfo = json.loads(request.body)

    if _check_token_authentication(projectInfo['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)

    creator = _get_username_from_token(projectInfo['token'])

    user = database.RetrieveUser(creator)
    if user is None:
        return JsonResponse({'error': 'Invalid User'}, status=404)

    project = ProjectModel(
        creator = creator,
        name = projectInfo['name'],
        description = projectInfo['description'],
        admins = [creator],
        users = [creator],
        viewers = [creator],
        tasks = [],
    )

    projectID = database.Add("Projects", project)
    user['projects'].append(projectID)
    database.UpdateUser(user)
    return JsonResponse({'message': 'Created project', '_id': projectID}, status=200)

### INPUTS
# token
# projectID
# name (optional)
# description (optional)
### OUTPUTS
# ---
def editProject(request):
    data = json.loads(request.body)

    if _check_token_authentication(data['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)

    editor = _get_username_from_token(data['token'])
    projects = database.RetrieveProjects([data['projectID']])
    if not projects:
        return JsonResponse({'error': 'Project not found'}, status=404)

    project = projects[0]
    if editor not in project['admins']:
        return JsonResponse({'error': 'User does not have permission to modify this project'}, status=403)

    if 'name' in data:
        project['name'] = data['name']
    if 'description' in data:
        project['description'] = data['description']

    database.UpdateProject(project)

    return JsonResponse({'message': 'Project updated successfully'}, status=200)

### INPUTS
# token (of user in project)
# projectID
# username (of user being invited to project)
# permission (string either 'admin', 'user' or 'viewer')
### OUTPUTS
# ---
def inviteToProject(request):
    # user1 is the project admin, user2 is the invited user
    requestInfo = json.loads(request.body)
    if _check_token_authentication(requestInfo['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)
    
    username = _get_username_from_token(requestInfo['token'])
    project = database.RetrieveProjects([requestInfo['projectID']])[0]
    if project is None:
        return JsonResponse({'error': 'Invalid Project'}, status=404)
    if username not in project['admins']:
        return JsonResponse({'error': 'User does have permission to invite'}, status=403)
    if requestInfo['username'] in project['viewers']:
        return JsonResponse({'error': 'User is already in the project'}, status=400)
    
    user2 = database.RetrieveUser(requestInfo['username'])
    if user2 is None:
        return JsonResponse({'error': 'Invalid User'}, status=404)
    
    network2 = database.RetrieveNetwork(requestInfo['username'])
    if username not in network2['friends']:
        return JsonResponse({'error': 'User is not a connection'}, status=400)
    request = next(filter(lambda request : request['id'] == requestInfo['projectID'], network2['project_requests']), None)
    if request != None:
        return JsonResponse({'error': 'User has already been invited to project'}, status=400)
    if not 'permission' in requestInfo:
        return JsonResponse({'error': 'No permission set'})
    if not requestInfo['permission'] in {'admin', 'user', 'viewer'}:
        return JsonResponse({'error': 'Invalid permission set'})

    network2['project_requests'].append({
        "id": requestInfo['projectID'],
        "name": project['name'],
        "permission": requestInfo['permission']
    })
    database.UpdateNetwork(network2)

    _sendProjectInviteNotification(username, requestInfo['username'], requestInfo['projectID'])
    return JsonResponse({'message': 'Connection invited successfully'}, status=200)

### INPUTS
# token
# projectID
# accept (boolean of whether the invite should be accepted)
### OUTPUTS
# ---
def handleProjectInvite(request):
    requestInfo = json.loads(request.body)
    if _check_token_authentication(requestInfo['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)
    username = _get_username_from_token(requestInfo['token'])
    
    project = database.RetrieveProjects([requestInfo['projectID']])[0]
    if project is None:
        return JsonResponse({'error': 'Invalid Project'}, status=404)
    
    user = database.RetrieveUser(username)
    if user is None:
        return JsonResponse({'error': 'Invalid User'}, status=404)
    
    network = database.RetrieveNetwork(username)
    request = next(filter(lambda request : request['id'] == requestInfo['projectID'], network['project_requests']), None)
    
    if request == None:
        return JsonResponse({'error': 'User has not been invited to project'}, status=400)
    
    network['project_requests'].remove(request)
    database.UpdateNetwork(network)

    if requestInfo['accept'] == True:
        match request['permission']:
            case 'admin':
                project['admins'].append(username)
                project['users'].append(username)
                project['viewers'].append(username)
            case 'user':
                project['users'].append(username)
                project['viewers'].append(username)
            case 'viewer':
                project['viewers'].append(username)
            case _:
                return JsonResponse({'error': 'Invalid invite request'}, status=400)
        
        user['projects'].append(requestInfo['projectID'])
        database.UpdateUser(user)
        database.UpdateProject(project)
        return JsonResponse({'message': 'Project joined successfully'}, status=200)
    else:
        return JsonResponse({'message': 'Project invite declined successfully'}, status=200)

### INPUTS
# token (of admin user)
# projectID
# username (of new admin user)
### OUTPUTS
# ---
def makeProjectAdmin(request):
    requestInfo = json.loads(request.body)
    if _check_token_authentication(requestInfo['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)
    username = _get_username_from_token(requestInfo['token'])

    project = database.RetrieveProjects([requestInfo['projectID']])[0]
    if project is None:
        return JsonResponse({'error': 'Invalid Project'}, status=404)
    
    user = database.RetrieveUser(username)
    if user is None:
        return JsonResponse({'error': 'Invalid User'}, status=404)
    user2 = database.RetrieveUser(requestInfo['username'])
    if user2 is None:
        return JsonResponse({'error': 'Invalid User'}, status=404)
    
    if username not in project['admins']:
        return JsonResponse({'error': 'User does not have permission to give administrator access'}, status=403)
    if user2['username'] not in project['viewers']:
        return JsonResponse({'error': 'User not a member of the project'}, status=404)
    if user2['username'] in project['admins']:
        return JsonResponse({'error': 'User is already a project administrator'}, status=404)
    
    project['admins'].append(user2['username'])
    if user2['username'] not in project['users']:
        project['users'].append(user2['username'])
    database.UpdateProject(project)
    return JsonResponse({'message': 'User promoted successfully'}, status=200)


### INPUTS
# token (of admin user)
# projectID
### OUTPUTS
# ---
def removeProject(request):
    data = json.loads(request.body)
    if _check_token_authentication(data['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)
    
    username = _get_username_from_token(data['token'])

    project = database.RetrieveProjects([data['projectID']])[0]
    if project is None:
        return JsonResponse({'error': 'Invalid Project'}, status=404)
    
    user = database.RetrieveUser(username)
    if user is None:
        return JsonResponse({'error': 'Invalid User'}, status=404)
    
    if username not in project['admins']:
        return JsonResponse({'error': 'User does not have permission to delete the project'}, status=403)
    
    # Remove the project from each user's project list
    for user in project['viewers']:
        user_data = database.RetrieveUser(user)
        user_data['projects'].remove(data['projectID'])
        database.UpdateUser(user_data)

    # Remove tasks
    for task in project['tasks']:
        _removeTask(task)
    
    # Remove the project from the database
    database.Delete("Projects", data['projectID'])

    return JsonResponse({'message': 'Project removed successfully'}, status=200)

### INPUTS
# token
# projectID
### OUTPUTS
# ---
def leaveProject(request):
    data = json.loads(request.body)
    if _check_token_authentication(data['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)
    
    username = _get_username_from_token(data['token'])

    project = database.RetrieveProjects([data['projectID']])[0]
    if project is None:
        return JsonResponse({'error': 'Invalid Project'}, status=404)
    
    user = database.RetrieveUser(username)
    if user is None:
        return JsonResponse({'error': 'Invalid User'}, status=404)
    if username not in project['viewers']:
        return JsonResponse({'error': 'User is not in the project'}, status=403)
    
    if username in project['admins']:
        project['admins'].remove(username)
    if username in project['users']:
        project['users'].remove(username)
    project['viewers'].remove(username)

    tasksData = database.RetrieveTasks(project['tasks'])
    for task in tasksData:
        if username in task['assigned_to']:
            task['assigned_to'].remove(username)
            database.UpdateTask(task)
        if task['_id'] in user['tasks']:
            user['tasks'].remove(task['_id'])
    user['projects'].remove(data['projectID'])
    database.UpdateUser(user)
    database.UpdateProject(project)

    return JsonResponse({'message': 'Project left successfully'}, status=200)