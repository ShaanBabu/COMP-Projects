import json
from django.http import JsonResponse
from .helpers import _check_token_authentication, _get_username_from_token
from .. import database
from datetime import datetime


### INPUTS
# token
### OUTPUTS
# list of notifications
# notifications contain:
# message
# timestamp
def getNotifications(request):
    data = json.loads(request.body)
    if _check_token_authentication(data['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)

    username = _get_username_from_token(data['token'])

    user = database.RetrieveUser(username)
    if user is None:
        return JsonResponse({'error': 'Invalid user'}, status=404)
    
    return JsonResponse(user['notifications'], safe=False)

### INPUTS
# token
# on_friend_request (optional boolean)
# on_friend_accept (optional boolean)
# on_project_invite (optional boolean)
# on_assignment (optional boolean)
# on_ping (optional boolean)
# on_deadline7 (optional boolean)
# on_deadline3 (optional boolean)
# on_deadline1 (optional boolean)
### OUTPUTS
# ---
def setNotifications(request):
    data = json.loads(request.body)
    if _check_token_authentication(data['token']) is None:
        return JsonResponse({'error': 'Invalid or expired token'}, status=401)
    
    username = _get_username_from_token(data['token'])

    user = database.RetrieveUser(username)
    if user is None:
        return JsonResponse({'error': 'Invalid user'}, status=404)
    
    nSettings = data['notification_settings']

    if 'on_friend_request' in nSettings:
        user['notification_settings']['on_friend_request'] = nSettings['on_friend_request']
    if 'on_friend_accept' in nSettings:
        user['notification_settings']['on_friend_accept'] = nSettings['on_friend_accept']
    if 'on_project_invite' in nSettings:
        user['notification_settings']['on_project_invite'] = nSettings['on_project_invite']
    if 'on_assignment' in nSettings:
        user['notification_settings']['on_assignment'] = nSettings['on_assignment']
    if 'on_ping' in nSettings:
        user['notification_settings']['on_ping'] = nSettings['on_ping']
    if 'on_deadline7' in nSettings:
        user['notification_settings']['on_deadline7'] = nSettings['on_deadline7']
    if 'on_deadline3' in nSettings:
        user['notification_settings']['on_deadline3'] = nSettings['on_deadline3']
    if 'on_deadline1' in nSettings:
        user['notification_settings']['on_deadline1'] = nSettings['on_deadline1']

    database.UpdateUser(user)

    return JsonResponse({'message': 'Notification settings updated successfully'}, status=200)

def _sendTaskAssignNotification(sender, receiver, taskID):
    r = database.RetrieveUser(receiver)
    if (sender == receiver or r['notification_settings']['on_assignment'] == False):
        return
    
    task = database.RetrieveTasks([taskID])[0]
    project = database.RetrieveProjects([task['project']])[0]
    r['notifications'].append({
        'message': "{assigner} assigned you a task: \"{task}\", in project: \"{project}\"".format(assigner=sender, task=task['name'], project=project['name']),
        'timestamp': datetime.now()
    })
    database.UpdateUser(r)

def _sendTaskStatusNotification(taskID, old, new, receiver):
    r = database.RetrieveUser(receiver)
    task = database.RetrieveTasks([taskID])[0]
    r['notifications'].append({
        'message': "Task \"{task}\" just changed status from \"{old}\" to \"{new}\"".format(task=task['name'], old=old, new=new),
        'timestamp': datetime.now()
    })
    database.UpdateUser(r)

def _sendFriendRequestNotification(sender, receiver):
    r = database.RetrieveUser(receiver)
    if (r['notification_settings']['on_friend_request'] == False):
        return
    
    r['notifications'].append({
        'message': "{sender} has sent you a friend request".format(sender=sender),
        'timestamp': datetime.now()
    })
    database.UpdateUser(r)

def _sendFriendAcceptNotification(sender, receiver):
    r = database.RetrieveUser(receiver)
    if (r['notification_settings']['on_friend_accept'] == False):
        return
    
    r['notifications'].append({
        'message': "{sender} has accepted your friend request".format(sender=sender),
        'timestamp': datetime.now()
    })
    database.UpdateUser(r)

def _sendFriendRejectNotification(sender, receiver):
    r = database.RetrieveUser(receiver)
    if (r['notification_settings']['on_friend_accept'] == False):
        return
    
    r['notifications'].append({
        'message': "{sender} has rejected your friend request".format(sender=sender),
        'timestamp': datetime.now()
    })
    database.UpdateUser(r)

def _sendProjectInviteNotification(sender, receiver, projectID):
    r = database.RetrieveUser(receiver)
    if (r['notification_settings']['on_project_invite'] == False):
        return
    
    project = database.RetrieveProjects([projectID])[0]
    r['notifications'].append({
        'message': "{sender} has invited you to project \"{project}\"".format(sender=sender, project=project['name']),
        'timestamp': datetime.now()
    })
    database.UpdateUser(r)

def _sendPingNotification(sender, receiver, taskID, comment):
    r = database.RetrieveUser(receiver)
    if (r['notification_settings']['on_ping'] == False):
        return
    
    task = database.RetrieveTasks([taskID])[0]
    r['notifications'].append({
        'message': "{sender} has pinged you in task \"{task}\": \"{comment}\"".format(sender=sender, task=task['name'], comment=comment),
        'timestamp': datetime.now()
    })
    database.UpdateUser(r)

# This function is called by runDaily.py in the siriBackend directory once per day
def _sendDeadlineNotifications():
    tasks = database.RetrieveTasks()
    for task in tasks:
        try:
            time_diff = (task['due_date'] - datetime.now()).days + 1
            if time_diff == 7:
                _sendDeadline7(task)
                print("sending notification for task {task}".format(task=task['name']))
            elif time_diff == 3:
                _sendDeadline3(task)
                print("sending notification for task {task}".format(task=task['name']))
            elif time_diff == 1:
                _sendDeadline1(task)
                print("sending notification for task {task}".format(task=task['name']))
        except:
            print("Errors with old backend info")
        
def _sendDeadline7(task):
    for username in task['assigned_to']:
        user = database.RetrieveUser(username)
        if user['notification_settings']['on_deadline7'] == False: continue
        user['notifications'].append({
            'message': "Task \"{task}\" is 7 days from the due date".format(task=task['name']),
            'timestamp': datetime.now()
        })
        database.UpdateUser(user)

def _sendDeadline3(task):
    for username in task['assigned_to']:
        user = database.RetrieveUser(username)
        if user['notification_settings']['on_deadline3'] == False: continue
        user['notifications'].append({
            'message': "Task \"{task}\" is 3 days from the due date".format(task=task['name']),
            'timestamp': datetime.now()
        })
        database.UpdateUser(user)

def _sendDeadline1(task):
    for username in task['assigned_to']:
        user = database.RetrieveUser(username)
        if user['notification_settings']['on_deadline1'] == False: continue
        user['notifications'].append({
            'message': "Task \"{task}\" is 1 day from the due date".format(task=task['name']),
            'timestamp': datetime.now()
        })
        database.UpdateUser(user)