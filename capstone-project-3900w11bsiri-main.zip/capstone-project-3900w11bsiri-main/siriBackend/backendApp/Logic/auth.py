import json
import datetime
from time import sleep
import jwt
from django.http import JsonResponse
from django.core.validators import validate_email
from django.core.exceptions import ValidationError
from django.contrib.auth.password_validation import validate_password
from django.contrib.auth.hashers import make_password, check_password
from .. import database
from ..Documents.User import UserModel
from ..Documents.Network import NetworkModel
from firebase_admin import auth
import firebase_admin
from firebase_admin._auth_utils import InvalidIdTokenError



cred = firebase_admin.credentials.Certificate("backendApp/siri-f7e3d-firebase-adminsdk-2rl7a-a72cba646a.json")
firebase_admin.initialize_app(cred)
### INPUTS
# username (of user signing up)
# email
# password
# name
### OUTPUTS
# ---
def signUpUser(request):
    newUser = json.loads(request.body)
    if database.RetrieveUser(newUser['username']):
        return JsonResponse({'error': 'Username already exists'}, status=400)
    try:
        validate_email(newUser['email'])
    except ValidationError:
        return JsonResponse({'error': 'Invalid email format'}, status=400)
    try:
        validate_password(newUser['password'])
    except ValidationError as ex:
        return JsonResponse({'error': str(ex)}, status=400)
    user = UserModel(
        username = newUser['username'],
        email = newUser['email'],
        password = make_password(newUser['password']),
        name = newUser['name'],
        notification_settings = {
            'on_friend_request': True,
            'on_friend_accept': True,
            'on_project_invite': True,
            'on_assignment': True,
            'on_ping': True,
            'on_deadline7': True,
            'on_deadline3': True,
            'on_deadline1': True,
        }
    )

    network = NetworkModel(
        username = newUser['username'],
        friends = [],
        friend_requests = [],
        project_requests = []
    )

    # MAYBE need to add code to handle current session once user signs up if loggin in
    # immediately after signing up . If not handle jwt in the login section only. 
    database.Add("Users", user)
    database.Add("Networks", network)
    return JsonResponse({'message': 'User created successfully'}, status=200)

### INPUTS
# username (of user logging in)
# password
### OUTPUTS
# token
def logInUser(request):
    existingUser = json.loads(request.body)
    user = database.RetrieveUser(existingUser['username'])
    if user is None:
        return JsonResponse({'error': 'Invalid username or password'}, status=400)
    
    if not check_password(existingUser['password'], user['password']):
        return JsonResponse({'error': 'Invalid username or password'}, status=400)
    
    token_data = {
        'username': existingUser['username'],
        'exp': datetime.datetime.utcnow().isoformat()
    }
    token = jwt.encode({'token':token_data}, 'SECRET', algorithm='HS256')

    return JsonResponse({'token': token}, status=201)


### INPUTS
# token (Google ID token)
### OUTPUTS
# token (JWT token for your backend)
def logInUserGoogle(request):
    data = json.loads(request.body)
    token = data['token']
    while True:
        try:
            idinfo = auth.verify_id_token(token)
            userid = idinfo['user_id']
            email = idinfo['email']
            name = idinfo['name']
            break 
        except InvalidIdTokenError:
            sleep(4)

    user = database.RetrieveUser(email)
    if user is None:
        user = UserModel(
            username=email,
            email=email,
            name=name,
            password=make_password(userid),
            notification_settings = {
            'on_friend_request': True,
            'on_friend_accept': True,
            'on_project_invite': True,
            'on_assignment': True,
            'on_ping': True,
            'on_deadline7': True,
            'on_deadline3': True,
            'on_deadline1': True,
        }
            
        )
        database.Add("Users", user)

        network = NetworkModel(
        username = email,
        friends = [],
        friend_requests = [],
        project_requests = []
        )
    
        database.Add("Networks", network)
    token_data = {
        'username': email,
        'exp': datetime.datetime.utcnow().isoformat()
    }
    token = jwt.encode({'token': token_data}, 'SECRET', algorithm='HS256')

    return JsonResponse({'token': token}, status=201)