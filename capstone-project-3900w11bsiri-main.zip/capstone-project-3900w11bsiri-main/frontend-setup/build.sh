#!/bin/bash
# This shell script is used to create a build for the frontend
# The NODE_OPTIONS setting is required otherwise javascript will run out of memory during build
export NODE_OPTIONS="--max-old-space-size=8192"
npm run build