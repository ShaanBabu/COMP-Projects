import { useState } from "react";
import { Route, Routes } from "react-router-dom";
import {Register} from "./pages/Register";
import {Login} from "./pages/Login";
import {Start} from "./pages/Start";
import { Dashboard } from "./pages/Home";
import { ProfilePage } from "./pages/ProfilePage";
import { ProjectPage } from "./pages/ProjectPage";
import { Context, initialValue } from "./context";
import { NetworkPage } from "./pages/NetworkPage";
import AboutUsPage from "./pages/About";
import UserProfile from "./pages/UserProfile";

function App() {
  const [loggedIn, setLoggedIn] = useState(initialValue.loggedIn);
  const [token, setToken] = useState(initialValue.token);
  const [username, setUsername] = useState(initialValue.username);
  const [notificationsSeen, setNotificationsSeen] = useState(initialValue.notificationsSeen);
  
  const getters = {
    loggedIn,
    token,
    username,
    notificationsSeen,
  }
  const setters = {
    setLoggedIn,
    setToken,
    setUsername,
    setNotificationsSeen,
  }
  
  return (
  <>
    <Context.Provider value={{ getters, setters }}>
      <Routes>
        <Route path = "/" element={<Start />} />
        <Route path = "/about" element={<AboutUsPage/>} />
        <Route path = "/login" element={<Login />} />
        <Route path = "/register" element={<Register />} />
        <Route path = "/home" element={<Dashboard />} />
        <Route path = "/profile" element={<ProfilePage />} />
        <Route path="/user/:username" element={<UserProfile />} />
        <Route path = "/projects" element={<ProjectPage />} />
        <Route path = "/networks" element={<NetworkPage />} />
      </Routes>
    </Context.Provider>  
  </>);
}



export default App;
