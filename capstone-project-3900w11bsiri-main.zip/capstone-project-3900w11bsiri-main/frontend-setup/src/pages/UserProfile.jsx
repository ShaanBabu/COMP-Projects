import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Button, Card, CardContent, Typography } from '@mui/material';
import { useContext, Context } from '../context';
import Navbar from './components/Navbar';
import TaskList from './components/TaskList';

function UserProfile() {
    const [userData, setUserData] = useState(null);
    const [showTaskList, setShowTaskList] = useState(false);
    const navigate = useNavigate();
    const getters = useContext(Context).getters;
    let { username } = useParams();
    const [showNotifications, setShowNotifications] = useState(false);
    const toggleNotifications = () => {
      setShowNotifications(!showNotifications);
    };

    useEffect(() => {
        if (!getters.loggedIn) {
            navigate('/');
            return;
        }

        const getData = async () => {
            const payload = {
                method: 'POST',
                headers: {
                    'Content-type': 'application/json'
                },
                body: JSON.stringify({
                    token: getters.token,
                    username: username
                })
            }
            
            const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/profile/user`, payload)
                .then(rawdata => rawdata.json());
            
            if (response.error) {
                alert(response.error);
            } else {
                setUserData(response);
            }
        }
        
        getData();
        const interval = setInterval(() => {
            getData();
        }, 5000);
        return () => clearInterval(interval);
    }, [getters.loggedIn, navigate, getters.token, username]);

    if (!userData) return <p>Loading...</p>; // loading state

    return (<>
        <Navbar toggleNotifications={toggleNotifications} showNotifications={showNotifications} />
        <Card sx={{ maxWidth: 800, margin: '0 auto', marginTop: 2 }}>
            <CardContent>
                <Typography variant="h5" component="div" gutterBottom>
                    {userData.name}
                </Typography>
                <Typography variant="h6">
                    Email: {userData.email}
                </Typography>
                <Typography variant="h6">
                    Title: {userData.title || 'Not provided'}
                </Typography>
                <Typography variant="h6">
                    Birthday: {userData.birthday ? new Date(userData.birthday).toLocaleDateString() : 'Not provided'}
                </Typography>
                <Typography variant="h6">
                    Projects: {userData.projects && userData.projects.length ? userData.projects.join(", ") : 'No projects'}
                </Typography>
                <br />
                <Button variant='contained' color='secondary' onClick={() => {setShowTaskList(!showTaskList)}}>Show Task List</Button>
                <br /><br />
                {showTaskList && <TaskList username={username}/>}
            </CardContent>
        </Card>
    </>);
}

export default UserProfile;
