import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import Avatar from "@mui/material/Avatar";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import IconButton from "@mui/material/IconButton";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import { getAuth, GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import GoogleLogo from '../Pictures/Google__G__Logo.svg.png';
import { Context } from "../context";
import { useContext } from "react";
import { app } from './firebase';
export function Register() {
  const [inputs, setInputs] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();
  const setters = useContext(Context).setters;

  const handleChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    setInputs((values) => ({ ...values, [name]: value }));
  };

  const handleTogglePassword = () => {
    setShowPassword((prevShowPassword) => !prevShowPassword);
  };

  const handleGoogleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(getAuth(app), provider);
      const user = result.user;
  
      user
        .getIdToken(true)
        .then(async (idToken) => {
          console.log(idToken)
          const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/auth/googleLogin`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              token: idToken,
            }),
          });
          const data = await response.json();
  
          if (data.error) {
            alert(data.error);
          } else {
            setters.setToken(data.token);
            setters.setLoggedIn(true);
            setters.setUsername(user.displayName);
            navigate("/home");
          }
        })
        .catch((error) => {
          console.error('Error getting ID token: ', error);
        });
    } catch (error) {
      alert(error.message);
    }
  };

  const handleRegister = async () => {
    const payload = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        username: inputs["username"],
        password: inputs["password"],
        email: inputs["email"],
        name: inputs["name"],
      }),
    };
    const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/auth/register`, payload).then((rawdata) => {
      return rawdata.json();
    });
    if (response.error) {
      alert(response.error);
    } else {
      const payload2 = {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          username: inputs["username"],
          password: inputs["password"],
        }),
      };
      const response2 = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/auth/login`, payload2).then((rawdata) => {
        return rawdata.json();
      });
      if (response2.error) {
        alert(response2.error);
      } else {
        setters.setToken(response2["token"]);
        setters.setLoggedIn(true);
        setters.setUsername(inputs["username"]);
        navigate("/home");
      }
    }
  };

  return (
    <Container component="main" maxWidth="xs">
      <Box
        sx={{
          marginTop: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <Avatar sx={{ m: 1, bgcolor: "secondary.main" }}>
          <LockOutlinedIcon />
        </Avatar>
        <Typography component="h1" variant="h5">
          Create New Account
        </Typography>
        <Typography variant="body2">
          Already registered? <Link to="/login">Log in here</Link>
        </Typography>
        <Box component="form" noValidate sx={{ mt: 1 }}>
          <TextField
            margin="normal"
            required
            fullWidth
            id="name"
            label="Full Name"
            name="name"
            autoComplete="name"
            autoFocus
            onChange={handleChange}
          />
          <TextField
            margin="normal"
            required
            fullWidth
            name="username"
            label="Username"
            autoComplete="username"
            onChange={handleChange}
          />
          <TextField
            margin="normal"
            required
            fullWidth
            name="email"
            label="Email"
            type="email"
            autoComplete="email"
            onChange={handleChange}
          />
          <TextField
            margin="normal"
            required
            fullWidth
            name="password"
            label="Password"
            type={showPassword ? "text" : "password"}
            id="password"
            autoComplete="new-password"
            onChange={handleChange}
            InputProps={{
              endAdornment: (
                <IconButton
                  onClick={handleTogglePassword}
                  edge="end"
                  aria-label="toggle password visibility"
                >
                  {showPassword ? <VisibilityOff /> : <Visibility />}
                </IconButton>
              ),
            }}
          />
          <Button
            type="button"
            fullWidth
            variant="contained"
            sx={{ mt: 2, mb: 2 }}
            onClick={handleRegister}
            disabled={
              !('username' in inputs) ||
              !('password' in inputs) ||
              !('email' in inputs) ||
              !('name' in inputs) ||
              inputs['username'] == '' ||
              inputs['password'] == '' ||
              inputs['email'] == '' ||
              inputs['name'] == ''
            }
          >
            Sign Up
          </Button>

          <Button
            type="button"
            fullWidth
            variant="contained"
            sx={{ mt: 2, mb: 2 }}
            onClick={handleGoogleLogin}
            startIcon={
              <img
                src={GoogleLogo}
                alt="Google Logo"
                style={{ width: "24px", marginRight: "8px" }}
              />
            }
          >
            Continue with Google
          </Button>
        </Box>
      </Box>
    </Container>
  );
}