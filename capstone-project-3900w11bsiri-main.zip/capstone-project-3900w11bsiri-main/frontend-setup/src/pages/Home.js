import React, { useEffect, useState } from 'react';
import Navbar from './components/Navbar';
import { useContext, Context } from '../context';
import { useNavigate } from 'react-router-dom';

// Define the styles as an object
const styles = {
  title: {
    flexGrow: 1,
    textAlign: 'center',
  },
  sectionContainer: {
    textAlign: 'center',
    padding: '20px',
  },
  sectionHeading: {
    fontSize: '36px',
    marginBottom: '10px',
    textAlign: 'center',
  },
  taskContainer: {
    display: 'flex',
    justifyContent: 'center',
    flexWrap: 'wrap',
  },
  task: {
    backgroundColor: '#f8ba6f',
    borderRadius: '10px',
    padding: '20px',
    width: '300px',
    margin: '10px',
  },
  projectContainer: {
    display: 'flex',
    justifyContent: 'center',
    flexWrap: 'wrap',
  },
  project: {
    backgroundColor: '#ffed77',
    borderRadius: '10px',
    padding: '20px',
    width: '300px',
    margin: '10px',
  },
  taskTitle: {
    fontSize: '24px',
    marginBottom: '10px',
  },
  taskDescription: {
    fontSize: '16px',
  },
};

export function Dashboard() {
  const getters = useContext(Context).getters;
  const navigate = useNavigate();
  const [projects, setProjects] = useState([]);
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    if (!getters.loggedIn) {
      navigate('/');
      return;
    }
    // Get projects information
    const getData = async () => {
      const payload = {
        method: 'POST',
        headers: {
          'Content-type': 'application/json'
        },
        body: JSON.stringify({
          token: getters.token
        })
      }
      const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/project/display`, payload).then((rawdata) => {
        return rawdata.json();
      });
      if (response.error) {
        alert(response.error);
      } else {
        setProjects(response);
      }
      const payload2 = {
        method: 'POST',
        headers: {
          'Content-type': 'application/json'
        },
        body: JSON.stringify({
          token: getters.token
        })
      }
      const response2 = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/tasklist/view`, payload).then((rawdata) => {
        return rawdata.json()
      });
      if (response2.error) {
        alert(response2.error);
      } else {
        setTasks(response2);
      }
    }
    getData();
    const interval = setInterval(() => {
      getData();
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const [showNotifications, setShowNotifications] = useState(false);
  
  const toggleNotifications = () => {
    setShowNotifications(!showNotifications);
  };
  
  return (
    <div>
      <Navbar toggleNotifications={toggleNotifications} showNotifications={showNotifications} />
      {/* Today's Tasks Section */}
      <div style={styles.sectionContainer}>
        <h2 style={styles.sectionHeading}>Today's Tasks</h2>
        <div style={styles.taskContainer}>
          {/* Map over tasks and create task items */}
          {tasks.length === 0 && (<h3>No Tasks</h3>)}
          {/* Max 4 tasks shown */}
          {tasks.slice(0, 4).map((task) => (
            <div style={styles.task}>
              <h3 style={styles.taskTitle}>{task.name}</h3>
              <p style={styles.taskDescription}>{task.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Current Projects Section */}
      <div style={styles.sectionContainer}>
        <h2 style={styles.sectionHeading}>Current Projects</h2>
        <div style={styles.projectContainer}>
          {/* Map over projects and create project items */}
          {projects.length === 0 && (<h3>No Projects</h3>)}
          {/* Max 4 projects shown */}
          {projects.slice(0, 4).map((project) => (
            <div style={styles.project}>
              <h3 style={styles.taskTitle}>{project.name}</h3>
              <p style={styles.taskDescription}>{project.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
