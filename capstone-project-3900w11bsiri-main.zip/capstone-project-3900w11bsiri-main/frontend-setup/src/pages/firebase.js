// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCIyDN4v2u-dqW5Zf-sUQnyDtQMgOL5ha4",
  authDomain: "siri-f7e3d.firebaseapp.com",
  projectId: "siri-f7e3d",
  storageBucket: "siri-f7e3d.appspot.com",
  messagingSenderId: "288654087561",
  appId: "1:288654087561:web:ab0335228091c91f873d58",
  measurementId: "G-BD47K5DQHJ"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);