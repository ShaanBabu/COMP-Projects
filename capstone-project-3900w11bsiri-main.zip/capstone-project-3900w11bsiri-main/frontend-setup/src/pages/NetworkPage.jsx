
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useContext, Context } from '../context';
import { Button, TextField, Typography, Paper, Container, Box, Divider } from '@mui/material';
import Navbar from './components/Navbar';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { Grid } from '@mui/material';



export function NetworkPage() {
  const getters = useContext(Context).getters;
  const navigate = useNavigate();
  const [network, setNetwork] = useState([]); // State to store the network
  const [connectionRequests, setConnectionRequests] = useState([]);
  const [projectInvites, setProjectInvites] = useState([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [addUsername, setAddUsername] = useState("");
  const [refresh, setRefresh] = useState(0);
  const toggleNotifications = () => {
    setShowNotifications(!showNotifications);
  };

  useEffect(() => {
    if (!getters.loggedIn) {
      navigate('/');
      return;
    }
    // Get network information
    const getData = async () => {
      const payload = {
        method: 'POST',
        headers: {
          'Content-type': 'application/json'
        },
        body: JSON.stringify({
          token: getters.token
        })
      }
      const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/connections/display`, payload).then((rawdata) => {
        return rawdata.json();
      });
      if (response.error) {
        alert(response.error);
      } else {
        setNetwork(response['connections']);
        setConnectionRequests(response['connectionRequests']);
        setProjectInvites(response['projectInvites']);
      }
    }
    getData();
    const interval = setInterval(() => {
      getData();
    }, 5000);
    return () => clearInterval(interval);
  }, [refresh]);

  const theme = createTheme({
    palette: {
      primary: {
        main: '#FFA500',  // color code for orange
      },
    },
  });

  const handleConnectionRequest = async (connection, accept) => {
    const payload = {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify({
        token: getters.token,
        username: connection,
        accept: accept
      })
    }
    const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/connections/accept`, payload).then((rawdata) => {
      return rawdata.json();
    });
    if (response.error) {
      alert(response.error);
    } else {
      setRefresh(refresh + 1);
    }
  }

  const handleProjectInvite = async (project, accept) => {
    const payload = {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify({
        token: getters.token,
        projectID: project['id'],
        accept: accept
      })
    }
    const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/project/accept`, payload).then((rawdata) => {
      return rawdata.json();
    });
    if (response.error) {
      alert(response.error);
    } else {
      setRefresh(refresh + 1);
    }
  }

  const handleAddConnection = useCallback(async () => {
    const payload = {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify({
        token: getters.token,
        username: addUsername
      })
    };
    const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/connections/add`, payload).then((rawdata) => {
      return rawdata.json();
    });
    if (response.error) {
      alert(response.error);
    } else {
      setAddUsername("");
    }
  }, [getters.token, addUsername]);
  
  return (
    <div>
      <Navbar toggleNotifications={toggleNotifications} showNotifications={showNotifications} />
      <Container>
        <Box sx={{ mt: 5 }}>
          <Typography variant="h4" component="h1" gutterBottom align="center">
            My Networks
          </Typography>
          <Divider />
        </Box>

        <Box sx={{ mt: 3, display: 'flex', justifyContent: 'center' }}>
          <TextField
            label="Add Connection"
            variant="outlined"
            value={addUsername}
            onChange={(event) => {
              setAddUsername(event.target.value);
            }}
            style={{ marginRight: "10px" }}
          />
          <ThemeProvider theme={theme}>
            <Button variant="contained" color="primary" onClick={handleAddConnection}>
              Add
            </Button>
          </ThemeProvider>
        </Box>

        <Grid container spacing={3} sx={{ mt: 5 }}>
          <Grid item xs={12} md={4}>
            <Paper elevation={3} sx={{ p: 3 }}>
              <Typography variant="h5" gutterBottom>
                Connections
              </Typography>
              {network.map((connection) => (
                <Box sx={{ mt: 1, cursor: 'pointer' }} key={connection} onClick={() => navigate(`/user/${connection}`)}>
                  <Typography variant="body1">
                    {connection}
                  </Typography>
                  <Divider sx={{ mt: 1 }} />
                </Box>
              ))}
              {network.length === 0 && 'No connections'}
            </Paper>
          </Grid>

          <Grid item xs={12} md={4}>
            <Paper elevation={3} sx={{ p: 3 }}>
              <Typography variant="h5" gutterBottom>
                Connection Requests
              </Typography>
              {connectionRequests.map((connection) => (
                <Box sx={{ mt: 1 }} key={connection}>
                  <Typography variant="body1">
                    {connection}
                  </Typography>
                  <Box sx={{ mt: 1 }}>
                    <Button variant='outlined' color="primary" onClick={() => handleConnectionRequest(connection, true)}>Accept</Button>
                    <Button variant='outlined' color="secondary" sx={{ ml: 2 }} onClick={() => handleConnectionRequest(connection, false)}>Decline</Button>
                  </Box>
                  <Divider sx={{ mt: 1 }} />
                </Box>
              ))}
              {connectionRequests.length === 0 && 'No connection requests'}
            </Paper>
          </Grid>

          <Grid item xs={12} md={4}>
            <Paper elevation={3} sx={{ p: 3 }}>
              <Typography variant="h5" gutterBottom>
                Project Invites
              </Typography>
              {projectInvites.map((project) => (
                <Box sx={{ mt: 1 }} key={project['id']}>
                  <Typography variant="body1">
                    {project['name']}
                  </Typography>
                  <Box sx={{ mt: 1 }}>
                    <Button variant='outlined' color="primary" onClick={() => handleProjectInvite(project, true)}>Accept</Button>
                    <Button variant='outlined' color="secondary" sx={{ ml: 2 }} onClick={() => handleProjectInvite(project, false)}>Decline</Button>
                  </Box>
                  <Divider sx={{ mt: 1 }} />
                </Box>
              ))}
              {projectInvites.length === 0 && 'No project invites'}
            </Paper>
          </Grid>
        </Grid>
      </Container>
    </div>
  );
}

export default NetworkPage;