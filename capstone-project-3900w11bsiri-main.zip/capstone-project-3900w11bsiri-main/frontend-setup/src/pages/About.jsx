import React from 'react';
import { Typography, Button, Grid, Container, Box, Paper } from '@mui/material';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import companyIcon from '../Pictures/companyLogo.png';
import team from '../Pictures/Team.png';
import useMediaQuery from '@mui/material/useMediaQuery';


const AboutUsPage = () => {
  const isSmallScreen = useMediaQuery('(max-width:600px)');

const styles = {
  root: {
    backgroundColor: '#fff',
    color: '#000',
    margin: 0,
    padding: 0,
  },
  appBar: {
    backgroundColor: '#fff',
    padding: '8px',
    textAlign: 'left',
  },
  companyIcon: {
    width: 50,
    height: 50,
  },
  navbarLinks: {
    display: 'flex',
    alignItems: 'center',
    marginLeft: 'auto',
    flexWrap: 'nowrap',
    overflowX: 'auto',
  },
  navbarLink: {
    marginRight: isSmallScreen ? '4px' : '8px', // reduce margin on small screens
    color: '#000',
    textDecoration: 'none',
    fontSize: isSmallScreen ? '12px' : '16px', // reduce font size on small screens
  },
  startButton: {
    padding: isSmallScreen ? '6px 12px' : '12px 24px', // reduce padding on small screens
    borderRadius: '4px',
    border: 'none',
    backgroundColor: '#ff9e0b',
    color: '#000',
    fontSize: isSmallScreen ? '12px' : '16px', // reduce font size on small screens
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'background-color 0.3s ease',
    '&:hover': {
      backgroundColor: '#333333',
      color: '#fff',
    },
  },
  imageBar: {
    // backgroundImage: `url(${team})`,
    backgroundSize: 'cover',
    width: '200%',
    height: '100px',
  },
  startImages: {
    display: 'flex',
    justifyContent: 'center',
    marginTop: '50px',
  },
  startImagesIcon: {
    width: '100%',
    height: 'auto',
  },
};


  return (
    <div style={styles.root}>
      <AppBar position="static" style={styles.appBar}>
        <Toolbar>
          <a href="/">
            <img src={companyIcon} alt="Company Logo" style={styles.companyIcon} />
          </a>
          <div style={styles.navbarLinks}>
            <a href="/about">
              <Button variant="text" style={styles.navbarLink}>
                About Us
              </Button>
            </a>
            <a href="/login">
              <Button variant="text" style={styles.navbarLink}>
                Log In
              </Button>
            </a>
            <a href="/register">
              <Button variant="contained" style={styles.startButton}>
                Get Started
              </Button>
            </a>
          </div>
        </Toolbar>
      </AppBar>

      <Box>
        <Container>
          <Grid container spacing={3}>
            <Grid item xs={12} sm={6}>
              <Box sx={{ padding: '50px 0', textAlign: 'left', mt: 10 }}>
                <Typography variant="h2" component="h2" gutterBottom>
                  So <span style={{ color: 'orange' }}>Who</span> Are We?
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={10} sm={6}>
              <Box sx={{ padding: '50px 0', textAlign: 'center', mt: 5 }}>
                <Typography variant="subtitle1" align="center" gutterBottom>
                  We are a task manager website dedicated to helping individuals and teams efficiently organize and manage their tasks. With our intuitive and user-friendly platform, we empower users to streamline their workflow, prioritize tasks, and collaborate seamlessly with their team members. Whether you're a busy professional, a student, or a project manager, our task manager offers a centralized hub to create, track, and complete tasks efficiently. We believe in the power of productivity and strive to provide a reliable and feature-rich solution that enhances your productivity and enables you to achieve your goals with ease.
                </Typography>
              </Box>
            </Grid>
          </Grid>

          <div style={styles.startImages}>
            <img src={team} alt="Start Images" style={styles.startImagesIcon} />
          </div>

          <Grid container spacing={10} sx={{ marginTop: '10px', marginBottom: '50px' }}>
            <Grid item xs={12} md={6}>
              <Paper style={{
                padding: '2rem',
                borderRadius: '1%',
                boxShadow: '0px 10px 25px rgba(0,0,0,0.1)',
                textAlign: 'center'
              }}>
                <Typography variant="h4" component="h3" gutterBottom>
                  Our Mission
                </Typography>
                <Typography variant="body1">
                  Our mission is to create a platform that enables teams to work efficiently and effectively.
                </Typography>
              </Paper>
            </Grid>
            <Grid item xs={12} md={6}>
              <Paper style={{
                padding: '2rem',
                borderRadius: '1%',
                boxShadow: '0px 10px 25px rgba(0,0,0,0.1)',
                textAlign: 'center'
              }}>
                <Typography variant="h4" component="h3" gutterBottom>
                  Our Vision
                </Typography>
                <Typography variant="body1">
                  We envision a future where all teams can work seamlessly, regardless of their location or size.
                </Typography>
              </Paper>
            </Grid>

            <Grid item xs={12}> 
              <Typography variant="h3" align="center" gutterBottom>
                What We Offer
              </Typography>
            </Grid>

            

            <Grid item xs={12} md={4}>
              <Paper style={{
                padding: '2rem',
                borderRadius: '1%', 
                boxShadow: '0px 10px 25px rgba(0,0,0,0.1)', 
                textAlign: 'center' 
              }}>
                <Typography variant="h4" component="h3" gutterBottom>
                  Create Tasks
                </Typography>
                <Typography variant="body1">
                  Add tasks onto a current project whenever.
                </Typography>
              </Paper>
            </Grid>
            <Grid item xs={12} md={4}>
              <Paper style={{
                padding: '2rem',
                borderRadius: '1%', 
                boxShadow: '0px 10px 25px rgba(0,0,0,0.1)', 
                textAlign: 'center',
                backgroundColor: 'orange' 
              }}>
                <Typography variant="h4" component="h3" gutterBottom>
                  Create Projects
                </Typography>
                <Typography variant="body1">
                  Work with team members and smash the deadlines.
                </Typography>
              </Paper>
            </Grid>
            <Grid item xs={12} md={4}>
              <Paper style={{
                padding: '2rem',
                borderRadius: '1%', 
                boxShadow: '0px 10px 25px rgba(0,0,0,0.1)', 
                textAlign: 'center' 
              }}>
                <Typography variant="h4" component="h3" gutterBottom>
                  Add Friends
                </Typography>
                <Typography variant="body1">
                  Work with a team cohesively on a single platform.
                </Typography>
              </Paper>
            </Grid>
            <Grid item xs={12} md={4}>
              <Paper style={{
                padding: '2rem',
                borderRadius: '1%', 
                boxShadow: '0px 10px 25px rgba(0,0,0,0.1)', 
                textAlign: 'center',
                backgroundColor:'orange' 
              }}>
                <Typography variant="h4" component="h3" gutterBottom>
                  Sort Tasks
                </Typography>
                <Typography variant="body1">
                Prioritize tasks and sort them accordingly.
                </Typography>
              </Paper>
            </Grid>
            <Grid item xs={12} md={4}>
              <Paper style={{
                padding: '2rem',
                borderRadius: '1%', 
                boxShadow: '0px 10px 25px rgba(0,0,0,0.1)', 
                textAlign: 'center' 
              }}>
                <Typography variant="h4" component="h3" gutterBottom>
                  Work together
                </Typography>
                <Typography variant="body1">
                  Add team members onto projects and work together.
                </Typography>
              </Paper>
            </Grid>
            <Grid item xs={12} md={4}>
              <Paper style={{
                padding: '2rem',
                borderRadius: '1%', 
                boxShadow: '0px 10px 25px rgba(0,0,0,0.1)', 
                textAlign: 'center', 
                backgroundColor: 'orange'
              }}>
                <Typography variant="h4" component="h3" gutterBottom>
                  Dashboard 
                </Typography>
                <Typography variant="body1">
                  See all your current due projects and tasks.
                </Typography>
              </Paper>
            </Grid>
          </Grid>
        </Container>
      </Box>
    </div>
  );
};


export default AboutUsPage;

