import React from 'react';
import { Card, CardContent, Typography } from '@mui/material';

const ProjectCardComponent = ({ project }) => {
    return (
        <Card key={project['_id']} sx={{ marginBottom: '1rem'}}>
            <CardContent>
                <Typography variant="body1" gutterBottom>
                    Project Name: <strong>{project['name']}</strong>
                </Typography>
                <Typography variant="body2" gutterBottom>
                    Description: {project['description']}
                </Typography>
                <Typography variant="body2" gutterBottom>
                    Project Number: {project['_id']}
                </Typography>
            </CardContent>
        </Card>
    );
};

export default ProjectCardComponent;
