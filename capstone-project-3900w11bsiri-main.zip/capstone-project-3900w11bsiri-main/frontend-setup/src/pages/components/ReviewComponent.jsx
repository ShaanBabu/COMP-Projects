import * as React from 'react';
import Avatar from '@mui/material/Avatar';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';

function ReviewComponent({ reviewer, reviewedUser, review, rating }) { // added rating
  return (
    <Box 
      sx={{ 
        display: 'flex', 
        mb: 2,
        alignItems: 'center',
      }}
    >
      <Avatar sx={{ mr: 2 }}>{reviewer[0].toUpperCase()}</Avatar>
      <Box>
        <Typography variant="subtitle2" component="p" gutterBottom>
          {reviewer} reviewed {reviewedUser}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          {review}
        </Typography>
        <Typography variant="body2" color="text.secondary">  {/* display the rating */}
          Rating: {rating} out of 5
        </Typography>
      </Box>
    </Box>
  );
}

export default ReviewComponent;
