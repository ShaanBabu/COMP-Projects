import React from 'react';
import { Card, CardContent, Typography } from '@mui/material';

const TaskCardComponent = ({ task }) => {
    return (
        <Card key={task['_id']} sx={{ marginBottom: '1rem'}}>
            <CardContent>
                <Typography variant="body2" gutterBottom color='gray' fontSize={11}>
                    Task ID: {task['_id']}
                </Typography>
                {console.log(task)}
                <Typography variant="body1" gutterBottom>
                    Task Name: <strong>{task['name']}</strong>
                </Typography>
                <Typography variant="body2" gutterBottom>
                    Due: {task['due_date'].slice(0, 10)}
                </Typography>
                <Typography variant="body2" gutterBottom>
                    Status: {task['status']}
                </Typography>
                <Typography variant="body2" gutterBottom>
                    Project: {task['project_name']}
                </Typography>
            </CardContent>
        </Card>
    );
};

export default TaskCardComponent;