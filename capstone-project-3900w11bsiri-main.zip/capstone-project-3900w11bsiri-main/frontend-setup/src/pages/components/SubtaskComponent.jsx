import * as React from 'react';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Checkbox from '@mui/material/Checkbox';

function SubTaskComponent({ title, description, dueDate, token, subtaskID, checked }) {
  const [isCompleted, setIsCompleted] = React.useState(checked);

  async function handleCheckboxChange(event) {
    const isChecked = event.target.checked;
    const payload = {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify({
        token: token,
        subtaskID: subtaskID,
        checked: isChecked
      })
    };
  
    const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/subtask/check`, payload)
      .then((rawData) => rawData.json());
  
    if (response.error) {
      alert(response.error);
    } else {
      // update state only after receiving successful response from the server
      setIsCompleted(isChecked);
      console.log(response);
    }
  }
  return (
    <Box 
      sx={{ 
        display: 'flex', 
        mb: 2,
        alignItems: 'center',
      }}
    >
      <Box>
        <Typography variant="subtitle2" component="p" gutterBottom>
          {title}
        </Typography>
        <Typography variant="body2" component="p" gutterBottom>
          {description}
        </Typography>
        <Typography variant="body2" color="text.secondary" component="p" gutterBottom>
          Due: {new Date(dueDate).toLocaleDateString()}
        </Typography>
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
          }}
        >
          <Checkbox
            checked={isCompleted}
            onChange={handleCheckboxChange}
          />
          <Typography
            variant="body2"
            color="text.secondary"
            style={{ textDecoration: isCompleted ? 'line-through' : 'none' }}
          >
            {title}
          </Typography>
        </Box>
      </Box>
    </Box>
  );
}

export default SubTaskComponent;

