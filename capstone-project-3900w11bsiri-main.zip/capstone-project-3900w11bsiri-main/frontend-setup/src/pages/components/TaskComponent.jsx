import * as React from 'react';
import { useState} from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import TextField from '@mui/material/TextField';
import Button from '@mui/material/Button';
import Select from '@mui/material/Select';
import MenuItem from '@mui/material/MenuItem';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import { AttachFile as AttachFileIcon } from '@mui/icons-material';
import IconButton from '@mui/material/IconButton';
import DeleteIcon from '@mui/icons-material/Delete';
import Input from '@mui/material/Input';
import CreateIcon from '@mui/icons-material/Create';
import CommentIcon from '@mui/icons-material/Comment';
import { useContext } from 'react';
import { Context } from '../../context';
import CommentComponent from './CommentComponent';
import Link from '@mui/material/Link';
import SubTaskComponent from './SubtaskComponent';
import ListIcon from '@mui/icons-material/List';
import StarIcon from '@mui/icons-material/Star';
import StarBorderIcon from '@mui/icons-material/StarBorder';

function TaskComponent({ task, projectUsers, handleTaskUpdate, editPermission, handleTaskDelete, refreshTask, addReview }) {
  const getters = useContext(Context).getters;
  const [selectedTask, setSelectedTask] = useState(null);
  const [editedTask, setEditedTask] = useState(null);
  const [users, setUsers] = useState(projectUsers);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [attachedFiles, setAttachedFiles] = useState([]);
  const [filesToDelete, setFilesToDelete] = useState([]);
  const [commentsModal, setCommentsModal] = useState(false);
  const [comment, setComment] = useState('');
  const [pings, setPings] = useState([]);
  const [subTasks, setSubTasks] = useState([]);
  const [subTaskModal, setSubTaskModal] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [reviewedUser, setReviewedUser] = useState('');
  const [review, setReview] = useState('');
  const [isFollowing, setIsFollowing] = useState(task['followers'].includes(getters.username));
  const [rating, setRating] = useState('');

  const username = getters.username
  const reviewableUsers = task['assigned_to'].filter((user) => {return username != user})
  
  const submitReview = async () => {
    if (reviewedUser && review && rating) {
      let FormattedReview = `${task.name}: ${review}`;
      const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/task/review`, {
        method: 'POST',
        headers: {
          'Content-type': 'application/json',
        },
        body: JSON.stringify({
          token: getters.token,
          reviewedUser: reviewedUser,
          review: FormattedReview,
          rating: rating, // added this line
          taskId: task._id
        })
      });
  
      if (!response.ok) {
        // Handle error
        console.error('Error submitting review:', await response.text());
      } else {
        const data = await response.json();
        console.log('Successfully added review:', data);
        setReviewedUser("");
        setReview("");
        setRating("");
      }
    } else {
      // Show error if review or user is not selected
    }
  };
  
  const handleCardClick = () => {
    setSelectedTask(task);
    setEditedTask({ ...task });
    setUsers([...new Set([...users, ...task.assigned_to])]);
    setAttachedFiles(task.attachments || []); 
  };

  const handleClose = () => {
    setSelectedTask(null);
    setEditedTask(null);
    setFilesToDelete([]);
    setSelectedFiles([]);
  };

  const handleInputChange = (event) => {
    setEditedTask({
      ...editedTask,
      [event.target.name]: event.target.value,
    });
  };

  const handleUpdateClick = async () => {
    if (selectedFiles.length > 0) {
      for (const file of selectedFiles) {
        const formData = new FormData();
        formData.append('file', file.file);
        formData.append('token', getters.token);
        formData.append('taskId', task._id);
    
        await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/task/attach`, {
          method: 'POST',
          body: formData,
        })
          .then((response) => response.json())
          .then((data) => {
            console.log(data);
          })
          .catch((error) => {
            console.error('Error:', error);
          });
      }
    
      await handleTaskUpdate(editedTask);
      setSelectedFiles([]);
      handleClose();
    } else {
      await handleTaskUpdate(editedTask);
      setSelectedFiles([]);
      handleClose();
    }
    for (const file of filesToDelete) {
      await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/task/deleteFile`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          token: getters.token,
          taskId: task._id,
          file_id: file.file_id,
        }),
      })
        .then((response) => response.json())
        .then((data) => {
          console.log(data);
        })
        .catch((error) => {
          console.error('Error:', error);
        });
    }
    handleTaskUpdate(editedTask)
    setFilesToDelete([]);
  };
  
  const handleUserChange = (event, fieldName) => {
    setEditedTask({
      ...editedTask,
      [fieldName]: event.target.value,
    });
  };

  const handleFileAttach = (event) => {
    const files = Array.from(event.target.files).map(file => ({
      file,
      url: URL.createObjectURL(file),
    }));
    setSelectedFiles((prevFiles) => [...prevFiles, ...files]);
  
    setEditedTask((prevTask) => {
      if (prevTask) {
        let prevFiless = []
        if (prevTask.files) {
          prevFiless = prevTask.files;
        }
        return {
          ...prevTask,
          files: [...prevFiless, ...files],
        };
      }
      return prevTask;
    });
  };

  const handleFileRemove = (fileIndex) => {
    setSelectedFiles((prevFiles) => prevFiles.filter((_, index) => index !== fileIndex));
  };  

  const handleAttachedFileRemove = (fileIndex) => {
    const fileToRemove = attachedFiles[fileIndex];
    setAttachedFiles((prevFiles) => prevFiles.filter((_, index) => index !== fileIndex));
  
    setFilesToDelete((prevFiles) => {
      if (!prevFiles.some((file) => file.file_id === fileToRemove.file_id)) {
        return [...prevFiles, fileToRemove];
      } else {
        return prevFiles;
      }
    });
  };

  const sendComment = async () => {
    const payload = {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify({
        token: getters.token,
        taskId: task._id,
        comment: comment,
        pings: pings
      })
    }
    const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/task/comment`, payload).then((rawdata) => {
      return rawdata.json();
    });
    if (response.error) {
      alert(response.error);
    } else {
      refreshTask();
      setComment('');
      setPings([]);
    }
  }

  const createSubTask = async () => {
    
    // setSubTasks(prevSubTasks => [...prevSubTasks, {
    //   title: title,
    //   description: description,
    //   dueDate: dueDate,
    // }]);

    // // Clear the input fields after creating a new subtask.
    // setTitle("");
    // setDescription("");
    // setDueDate("");
    
    const payload = {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify({
        token: getters.token,
        taskID: task._id, 
        name: title,
        description: description,
        due_date: dueDate
      })
    }
    const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/subtask/create`, payload).then((rawdata) => {
      return rawdata.json();
    });
    if (response.error) {
      alert(response.error);
    } else {
      refreshTask();
      setTitle(''); 
      setDescription('');
      setDueDate('');
    }
  }

  const handleFollow = async () => {
    const newFollowingState = !isFollowing;
    setIsFollowing(newFollowingState);
    const options = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        token: getters.token,
        taskID: task._id,
      })
    }
    const apiUrl = `${process.env.REACT_APP_BACKEND_SERVER}/task/${newFollowingState ? 'follow' : 'unfollow'}`;
    const response = await fetch(apiUrl, options).then(data => data.json());
    if (response.error) {
      setIsFollowing(!newFollowingState);
      alert(response.error);
    } else {
      refreshTask();
    }
  }

  const modalStyle = {
    position: 'absolute', 
    top: '50%', 
    left: '50%', 
    transform: 'translate(-50%, -50%)', 
    bgcolor: 'background.paper', 
    boxShadow: 24, 
    p: 4,
    width: '50%',
    [`@media (max-width:600px)`]: {
      width: '90%',
    },
  };

  return (
    <React.Fragment>
      <Card 
        sx={{ 
          maxWidth: 250, 
          color: 'black',
          transition: '0.3s',
          '&:hover': {
            transform: 'translateY(-10px)',
            boxShadow: '0 4px 20px 0 rgba(0,0,0,0.12)'
          }
        }}
      >
        <CardContent>
          <Box display="flex" flexDirection="column" height="100%">
            <Box>
              <Typography variant="h5" component="div" gutterBottom>
                {task.name}
              </Typography>
              <Typography variant="body2" gutterBottom>
                  {task.due_date.slice(0, 10)}
              </Typography>
              <Typography sx={{ fontSize: 14 }} color="text.primary">
                {task.description}
              </Typography>
              <Typography sx={{ fontSize: 14 }} color="text.primary" mt={1}>
                Assigned To: {task.assigned_to.join(", ")}
              </Typography>
            </Box>
            {editPermission ? 
              <Box display='flex' justifyContent='space-between' mt="auto">
                <IconButton onClick={() => {handleTaskDelete(task)}} color="primary" aria-label="delete task" sx={{ml:-1}}>
                  <DeleteIcon />
                </IconButton>
                <IconButton onClick={() => {setCommentsModal(true)}} color="primary" aria-label="task-comments">
                  <CommentIcon />
                </IconButton>
                <IconButton onClick={handleCardClick} color="primary" aria-label="edit task">
                  <CreateIcon />
                </IconButton>
                <IconButton onClick={() => {setSubTaskModal(true)}} color="primary" aria-label="task-subtasks">
                  <ListIcon/>
                </IconButton>
                <IconButton onClick={handleFollow} color="primary" aria-label={isFollowing ? "unfollow task" : "follow task"}>
                  {isFollowing ? <StarIcon /> : <StarBorderIcon />}
                </IconButton>
              </Box>
              :
              <Box display='flex' justifyContent='space-between' mt="auto">
                <IconButton onClick={handleFollow} color="primary" aria-label={isFollowing ? "unfollow task" : "follow task"} sx={{ml:-1}}>
                  {isFollowing ? <StarIcon /> : <StarBorderIcon />}
                </IconButton>
              </Box>
            }
          </Box>
        </CardContent>
      </Card>

      <Modal
        open={!!selectedTask}
        onClose={handleClose}
      >
        <Box sx={modalStyle}>
          <Typography variant="h6" component="h2" gutterBottom>
            Edit Task
          </Typography>
          <Box sx={{ mt: 2 }}>
            <TextField
              fullWidth
              label="Name"
              name="name"
              value={editedTask?.name || ''}
              onChange={handleInputChange}
            />
            <TextField
              type="date"
              label="Due Date"
              name="due_date"
              value={editedTask?.due_date.slice(0, 10) || ''}
              onChange={handleInputChange}
              InputLabelProps={{ shrink: true }}
              sx={{ mt: 2 }}
            />
            <TextField
              fullWidth
              label="Description"
              name="description"
              value={editedTask?.description || ''}
              onChange={handleInputChange}
              sx={{ mt: 2 }}
            />

            <FormControl fullWidth sx={{ mt: 2 }}>
              <InputLabel id="status-select-label">Status</InputLabel>
              <Select
                labelId="status-select-label"
                label="Status"
                name="status"
                value={editedTask?.status || ''}
                onChange={handleInputChange}
              >
                <MenuItem value={'todo'}>To Do</MenuItem>
                <MenuItem value={'inprogress'}>In Progress</MenuItem>
                <MenuItem value={'done'}>Done</MenuItem>
              </Select>
            </FormControl>
            <FormControl fullWidth sx={{ mt: 2, mb: 1 }}>
              <InputLabel id="assignee-select-label">Assigned To</InputLabel>
              <Select
                labelId="assignee-select-label"
                label="Assigned To"
                value={editedTask?.assigned_to || ''}
                onChange={(e) => handleUserChange(e, 'assigned_to')}
                multiple
              >
                {users.map((user) => (
                  <MenuItem key={user} value={user}>
                    {user}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            {/* file */}
            <Input
              type="file"
              multiple
              onChange={handleFileAttach}
              sx={{ display: 'none' }}
              id="attach-files-input"
            />
            <label htmlFor="attach-files-input">
              {/* Button for selecting files */}
              <Button
                variant="outlined"
                component="span"
                startIcon={<AttachFileIcon />}
              >
                {/* Display the number of selected files */}
                {selectedFiles && selectedFiles.length > 0 ? `Attach Files (${selectedFiles.length})` : 'Attach Files'}
              </Button>
            </label>
            <Box sx={{ mt: 2 }}>
              {/* Display the selected files and a delete button for each */}
              {selectedFiles && selectedFiles.map((file, index) => (
                <Box key={index} display="flex" alignItems="center" marginBottom={1}>
                <Link 
                  href={file.url}
                  variant="body2" 
                  color="textSecondary"
                  underline="hover"
                  download={file.file.name}
                >
                  {file.file.name}
                </Link>
                  <IconButton 
                    size="small" 
                    onClick={() => handleFileRemove(index)}
                    sx={{ ml: 1 }}
                  >
                    <DeleteIcon fontSize="small" />
                  </IconButton>
                </Box>
              ))}
            </Box>
            <Box sx={{ mt: 2 }}>
              {/* Display the attached files */}
              {attachedFiles && attachedFiles.map((file, index) => (
                <Box key={index} display="flex" alignItems="center" marginBottom={1}>
                <Link 
                  href={`${process.env.REACT_APP_BACKEND_SERVER}/task/download?file_id=${file.file_id}`}
                  variant="body2" 
                  color="textSecondary"
                  underline="hover"
                  download
                >
                  {file.filename}
                </Link>
                  <IconButton 
                    size="small" 
                    onClick={() => handleAttachedFileRemove(index)}
                    sx={{ ml: 1 }}
                  >
                    <DeleteIcon fontSize="small" />
                  </IconButton>
                </Box>
              ))}
            </Box>
          </Box>
          <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end' }}>
            <Button onClick={handleClose}>Cancel</Button>
            <Button variant="contained" onClick={handleUpdateClick} sx={{ ml: 2 }}>
              Update
            </Button>
          </Box>
        </Box>
      </Modal>
      <Modal open={commentsModal} onClose={() => setCommentsModal(false)}>
        <Box sx={modalStyle}>
          <Typography variant="h5" component="div" gutterBottom>
            {task.name}
          </Typography>
          <Typography sx={{ fontSize: 14 }} color="text.primary">
            {task.description}
          </Typography>
          <FormControl fullWidth sx={{ mt: 2 }}>
            <InputLabel id="ping-select-label">Ping User</InputLabel>
            <Select
              labelId="ping-select-label"
              label="Ping User"
              multiple
              value={pings}
              onChange={(e) => setPings(e.target.value)}
            >
              {users.map((user) => (
                <MenuItem key={user} value={user}>
                  {user}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <TextField
            fullWidth
            label="Comment"
            name="comment"
            value={comment}
            onChange={(event) => setComment(event.target.value)}
            sx={{mt : 2, mb : 2}}
          />
          <Button variant='contained' onClick={sendComment} disabled={comment === ''} sx={{mb : 2}}>Add Comment</Button>

          {task.comments.slice().reverse().map((comment) => (
            <CommentComponent 
              username={comment.username}
              comment={comment.comment}
            />
          ))}
        </Box>
      </Modal>
      <Modal open={subTaskModal} onClose={() => setSubTaskModal(false)}>
        <Box sx={modalStyle}>
          <Typography variant="h5" component="div" gutterBottom>
            {task.name}
          </Typography>
          <Typography sx={{ fontSize: 14 }} color="text.primary">
            {task.description}
          </Typography>
          <TextField
            fullWidth
            label="Title"
            value={title}
            onChange={(event) => setTitle(event.target.value)}
            sx={{mt : 2, mb : 1}}
          />
          <TextField
            fullWidth
            label="Description"
            value={description}
            onChange={(event) => setDescription(event.target.value)}
            sx={{mt : 2, mb : 1}}
          />
          <TextField
            fullWidth
            type="date"
            label="Due Date"
            InputLabelProps={{ shrink: true }}
            name="dueDate"
            value={dueDate}
            onChange={(event) => setDueDate(event.target.value)}
            sx={{mt : 2, mb : 2}}
          />
            <Button variant='contained' onClick={createSubTask} disabled={title === "" || description === "" || dueDate === ""} sx={{mb : 2}}>Add Subtask</Button>
            {task.subtasks.map((subTask) => (
              <SubTaskComponent
                title={subTask.name}
                description={subTask.description}
                dueDate={subTask.due_date}
                checked={subTask.checked}
                token={getters.token}
                subtaskID={subTask._id}
              />
            ))}

        </Box>
      </Modal>
      
      {task.status === 'done' && reviewableUsers.length != 0 && (
        <>
          <FormControl fullWidth sx={{ mt: 2 }}>
            <InputLabel id="review-user-select-label">Review User</InputLabel>
            <Select
              labelId="review-user-select-label"
              label="Review User"
              value={reviewedUser}
              onChange={(e) => setReviewedUser(e.target.value)}
            >
              {reviewableUsers.map((user) => (
                <MenuItem key={user} value={user}>
                  {user}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <FormControl fullWidth sx={{ mt: 2 }}>
            <InputLabel id="rating-select-label">Rating</InputLabel>
            <Select
              labelId="rating-select-label"
              label="Rating"
              value={rating}
              onChange={(e) => setRating(e.target.value)}
            >
              {[1, 2, 3, 4, 5].map((value) => (
                <MenuItem key={value} value={value}>
                  {value}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <TextField
            fullWidth
            label="Review"
            value={review}
            onChange={(e) => setReview(e.target.value)}
            sx={{ mt: 2 }}
          />
          <Button variant="contained" onClick={submitReview} sx={{ mt: 2 }}>
            Submit Review
          </Button>
        </>
      )}

    </React.Fragment>
  );  
}

export default TaskComponent;
