import React, { useState } from 'react';
import { TextField, Box, Button, Modal, FormControl, InputLabel, Select, MenuItem } from '@mui/material';
import { useContext, Context } from '../../context';

const ProjectAdminModal = ({ showAdminModal, setShowAdminModal, project, handleProjectDelete, refreshProjects }) => {
  const getters = useContext(Context).getters;
  const [selectedUser, setSelectedUser] = useState('');
  const [projectInvite, setProjectInvite] = useState('');
  const [invitePermission, setInvitePermission] = useState('user');
  const [loadingConnections, setLoadingConnections] = useState(false);
  const [connections, setConnections] = useState([]);
  const [editedProject, setEditedProject] = useState({ ...project});

  const modalStyle = {
    position: 'absolute', 
    top: '50%', 
    left: '50%', 
    transform: 'translate(-50%, -50%)', 
    bgcolor: 'background.paper', 
    boxShadow: 24, 
    p: 4,
    width: '50%',
    [`@media (max-width:766px)`]: {
      width: '90%',
    },
  };

  const makeUserAdmin = async () => {
    if (selectedUser && project.admins.includes(getters.username)){
      const payload = {
        method: 'POST',
        headers: {
          'Content-type': 'application/json'
        },
        body: JSON.stringify({
          token: getters.token,
          projectID: project._id,
          username: selectedUser
        })
      }
      const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/project/makeAdmin`, payload).then((rawdata) => {
        return rawdata.json();
      });
      if (response.error) {
        alert(response.error);
      } else {
        setSelectedUser(''); // reset selected user
      }
    }
  };

  const handleInvite = async () => {
    const payload = {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify({
        token: getters.token,
        username: projectInvite,
        projectID: project['_id'],
        permission: invitePermission
      })
    }
    const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/project/invite`, payload).then((rawdata) => {
      return rawdata.json();
    });
    if (response.error) {
      alert(response.error);
    } else {
      setProjectInvite("");
    }
  };

  const fetchConnections = async () => {
    setLoadingConnections(true);
    const payload = {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify({
        token: getters.token
      })
    }
    const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/connections/display`, payload).then((rawdata) => {
      return rawdata.json();
    });
    if (response.error) {
      alert(response.error);
    } else {
      setConnections(response['connections']);
      setLoadingConnections(false);
    }
  };

  const connectionsToJoin = () => {
    return connections.filter((connection) => {
      return !project.viewers.includes(connection)
    })
  };

  const handleInputChange = (event) => {
    setEditedProject({
      ...editedProject,
      [event.target.name]: event.target.value,
    });
  };

  const handleProjectEdit = async () => {
    const payload = {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify({
        token: getters.token,
        projectID: project._id,
        name: editedProject.name,
        description: editedProject.description,
      })
    }
    const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/project/edit`, payload).then((rawdata) => {
      return rawdata.json();
    });
    if (response.error) {
      alert(response.error);
    } else {
      refreshProjects();
    }
  }

  return (
    <Modal open={showAdminModal} onClose={() => setShowAdminModal(false)}>
      <Box sx={{...modalStyle, '& .MuiFormControl-root': { mr: { sm: 2 }, mb: { xs: 2, sm: 0 }, minWidth: 150 }}}>
        <Box display="flex" flexDirection={{ xs: 'column', sm: 'row' }} alignItems="center" mb={3} mt={3}>
          <FormControl variant="outlined">
            <InputLabel id="user-select-label">Invite Connection</InputLabel>
            <Select
              labelId="user-select-label"
              id="user-select"
              value={projectInvite}
              onChange={event => setProjectInvite(event.target.value)}
              label="Invite Connection"
              onOpen={() => fetchConnections()}
            >
              {loadingConnections && <MenuItem value="" disabled>Loading...</MenuItem>}
              {!loadingConnections && connectionsToJoin().length === 0 && <MenuItem value="" disabled>No connections found</MenuItem>}
              {!loadingConnections && connectionsToJoin().map((user, index) => (
                <MenuItem value={user} key={index}>{user}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <FormControl>
            <InputLabel id='permission-label'>Permission</InputLabel>
            <Select
              labelId='permission-label'
              label='Permission'
              defaultValue='user'
              value={invitePermission}
              onChange={(event) => {
                setInvitePermission(event.target.value)
              }}                  
            >
              <MenuItem value='admin'>Administrator</MenuItem>
              <MenuItem value='user'>User</MenuItem>
              <MenuItem value='viewer'>Viewer</MenuItem>
            </Select>
          </FormControl>
          <Button variant='contained' sx={{ mx: 2 }} onClick={handleInvite} disabled={projectInvite===''}>Invite</Button>
        </Box>
        <Box display="flex" flexDirection={{ xs: 'column', sm: 'row' }} alignItems="center" mb={3} mt={3}>
          <FormControl variant="outlined">
            <InputLabel id="user-select-label">Select User</InputLabel>
            <Select
              labelId="user-select-label"
              id="user-select"
              value={selectedUser}
              onChange={e => setSelectedUser(e.target.value)}
              label="Select User"
            >
              <MenuItem value="" disabled>Select User</MenuItem>
              {project.viewers.filter((user) => {return !(project.admins.includes(user))}).map((user, index) => (
                <MenuItem value={user} key={index}>{user}</MenuItem>
              ))}
            </Select>
          </FormControl>
          <Button 
            variant="contained"
            onClick={makeUserAdmin}
            sx={{ backgroundColor: 'primary.main', color: '#fff', mr: 2 }}
            disabled={!selectedUser}
          >
            Make Admin
          </Button>
        </Box>
        <TextField
          fullWidth
          label="Name"
          name="name"
          value={editedProject?.name || ''}
          onChange={handleInputChange}
          sx={{ mb: 2 }}
        />
        <Box my={2} /> 
        <TextField
          fullWidth
          label="Description"
          name="description"
          value={editedProject?.description || ''}
          onChange={handleInputChange}
          sx={{ mb: 2 }}
        />
        <Box display='flex' justifyContent='space-between' sx={{mt: 2}}>
          <Button variant='contained' color='error' onClick={() => handleProjectDelete(project)}>
            Delete Project
          </Button>
          <Button variant='contained' disabled={(editedProject.name === project.name && editedProject.description === project.description)} onClick={handleProjectEdit}>
            Edit Project
          </Button>
        </Box>
      </Box>
    </Modal>
  );
};

export default ProjectAdminModal;


