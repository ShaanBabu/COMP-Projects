import * as React from 'react';
import { useState, useEffect } from 'react';
import Grid from '@mui/material/Grid';
import TaskComponent from './TaskComponent';
import { useContext, Context } from '../../context';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import CreateTaskModal from './CreateTaskModal';
import { IconButton, Typography } from '@mui/material';
import SettingsIcon from '@mui/icons-material/Settings';
import VisibilityIcon from '@mui/icons-material/Visibility';
import ProjectAdminModal from './ProjectAdminModal';
import AddIcon from '@mui/icons-material/Add';
import ReviewModal from './ReviewModal';

function ProjectComponent({ 
  project, 
  updateProject,
  handleProjectDelete,
  handleProjectLeave,
  refreshProjects
}) {
  const getters = useContext(Context).getters;
  const [tasks, setTasks] = useState([]);
  const [showAddTask, setShowAddTask] = useState(false);
  const [taskCounter, setTaskCounter] = useState(0);
  const [showAdminModal, setShowAdminModal] = useState(false);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [reviews, setReviews] = useState([]); 
  let isAdmin = false;
  let toDoTasks = [];
  let inProgressTasks = [];
  let doneTasks = [];
  const handleAddTaskClick = () => {
    setShowAddTask(true);
  };
  useEffect(() => {
    const getReviews = async () => {
      const payload = {
        method: 'POST',
        headers: {
          'Content-type': 'application/json'
        },
        body: JSON.stringify({
          token: getters.token,
          projectId: project._id,
        })
      }
      const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/task/review/display`, payload).then((rawdata) => {
        return rawdata.json();
      });
      if (response.error) {
        alert(response.error);
      } else {
        setReviews(response.reviews);
      }
    }
    getReviews();
    const interval = setInterval(() => {
      getReviews();
    }, 5000);
    return () => clearInterval(interval);
  }, [showReviewModal]);

  const addReview = (review) => {
    setReviews(prevReviews => [...prevReviews, review]);
  };
  console.log(project.admins)
  console.log(getters.username)
  if (project.admins.includes(getters.username)) {
    isAdmin = true;
  }
  console.log(isAdmin)
  useEffect(() => {
    const getData = async () => {
      const payload = {
        method: 'POST',
        headers: {
          'Content-type': 'application/json'
        },
        body: JSON.stringify({
          token: getters.token,
          projectID: project._id
        })
      }
      const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/task/display`, payload).then((rawdata) => {
        return rawdata.json();
      });
      if (response.error) {
        alert(response.error);
      } else {
        setTasks(response.tasks);
      }
    }
    getData();
    const interval = setInterval(() => {
      getData();
    }, 5000);
    return () => clearInterval(interval);
  }, [project, taskCounter]);

  const handleTaskCreate = async (task) => {
    const payload = {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify({
        token: getters.token,
        name: task['title'],
        description: task['description'],
        due_date: task['dueDate'],
        assigned_to: task['assigned_to'],
        projectID: project._id,
        status: "todo"
      })
    }
    const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/task/create`, payload).then((rawdata) => {
      return rawdata.json();
    });
    if (response.error) {
      alert(response.error);
    } else {
      setTaskCounter(prevCount => prevCount + 1);
      setShowAddTask(false);
    }
  };

  const handleTaskUpdate = async (updatedTask) => {
    const payload = {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify({
        token: getters.token,
        taskId: updatedTask._id,
        name: updatedTask.name,
        description: updatedTask.description,
        due_date: updatedTask.due_date,
        status: updatedTask.status,
        assigned_to: updatedTask.assigned_to
      })
    }
    const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/task/edit`, payload).then((rawdata) => {
      return rawdata.json();
    });
    if (response.error) {
      alert(response.error);
    } else {
      setTaskCounter(prevCount => prevCount + 1);
    }
  };

  const handleTaskDelete = async (task) => {
    const payload = {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify({
        token: getters.token,
        taskId: task._id
      })
    }
    const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/task/remove`, payload).then((rawdata) => {
      return rawdata.json();
    });
    if (response.error) {
      alert(response.error);
    } else {
      setTaskCounter(prevCount => prevCount + 1);
    }
  }

  const canEdit = (task) => {
    return project.admins.includes(getters.username) || task.assigned_to.includes(getters.username)
  }
  
  if (tasks) {
    toDoTasks = tasks.filter(task => task.status === 'todo');
    inProgressTasks = tasks.filter(task => task.status === 'inprogress');
    doneTasks = tasks.filter(task => task.status === 'done');
  }

  return (
  <Box sx={{ flex: 2 }}>
    <Typography variant="h4" display="inline">{project.name}</Typography>
    {/* ADMIN SETTINGS BUTTON */}
    {isAdmin && 
      <Button color="primary" variant="contained" startIcon={<SettingsIcon />} sx={{ml: 2, mb: 2}} onClick={() => {setShowAdminModal(true)}}>
        Settings
      </Button>
    }
    {/* ADMIN REVIEW VIEW */}
    {isAdmin && 
      <Button color="primary" variant="contained" startIcon={<VisibilityIcon />} sx={{ml: 2, mb: 2}} onClick={() => {setShowReviewModal(true)}}>
        View Reviews
      </Button>
    }


    <Button color='error' variant='contained' sx={{ml : 2, mb : 2}} onClick={() => handleProjectLeave(project)}>
      Leave
    </Button>
    <Typography variant="body1" gutterBottom>{project.description}</Typography>

    <Grid container justifyContent="center" spacing={2}>
      <Grid item xs={12} sm={6} md={4}>
        <Box bgcolor="#f8f9fa" p={2} mx={1}>
          <h2>To Do
            {/* CREATE TASK BUTTON */}
            {project.users.includes(getters.username) && <>
              <IconButton
                onClick={handleAddTaskClick} 
                sx={{ mb: 0.5, ml: 2 }}
                color="primary"
              >
                <AddIcon />
              </IconButton>
            </>}
          </h2>
          {toDoTasks.map((task, index) => (
            <Box my={1} key={index}>
              <TaskComponent task={task} handleTaskUpdate={handleTaskUpdate} projectUsers={project.users} editPermission={canEdit(task)} handleTaskDelete={handleTaskDelete} refreshTask={() => setTaskCounter(prevCount => prevCount + 1)}/>
            </Box>
          ))}
          {toDoTasks.length === 0 && "No tasks"}
        </Box>
      </Grid>
      <Grid item xs={12} sm={6} md={4}>
        <Box bgcolor="#f8f9fa" p={2} mx={1}>
          <h2>In Progress</h2>
          {inProgressTasks.map((task, index) => (
            <Box my={1} key={index}>
              <TaskComponent task={task} handleTaskUpdate={handleTaskUpdate} projectUsers={project.users} editPermission={canEdit(task)} handleTaskDelete={handleTaskDelete} refreshTask={() => setTaskCounter(prevCount => prevCount + 1)}/>
            </Box>
          ))}
          {inProgressTasks.length === 0 && "No tasks"}
        </Box>
      </Grid>
      <Grid item xs={12} sm={6} md={4}>
        <Box bgcolor="#f8f9fa" p={2} mx={1}>
          <h2>Done</h2>
          {doneTasks.map((task, index) => (
            <Box my={1} key={index}>
              <TaskComponent task={task} handleTaskUpdate={handleTaskUpdate} projectUsers={project.users} editPermission={canEdit(task)} handleTaskDelete={handleTaskDelete} refreshTask={() => setTaskCounter(prevCount => prevCount + 1)} addReview={addReview}/>
            </Box>
          ))}
          {doneTasks.length === 0 && "No tasks"}
        </Box>
      </Grid>
    </Grid>

    {showAddTask && (
      <CreateTaskModal 
        showAddTask={showAddTask} 
        setShowAddTask={setShowAddTask}
        handleTaskCreate={handleTaskCreate}
        projectName={project.name}
        projectUsers={project.users}
      />
    )}

    <ProjectAdminModal
      project={project}
      showAdminModal={showAdminModal} 
      setShowAdminModal={setShowAdminModal}
      handleProjectDelete={handleProjectDelete}
      refreshProjects={refreshProjects}
    />

    <ReviewModal
      reviews={reviews} // passing reviews as a prop
      project={project}
      showReviewModal={showReviewModal} 
      setShowReviewModal={setShowReviewModal}
    />

  </Box>);
}

export default ProjectComponent;
