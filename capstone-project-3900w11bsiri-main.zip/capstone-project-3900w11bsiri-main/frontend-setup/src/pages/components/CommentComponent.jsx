import * as React from 'react';
import Avatar from '@mui/material/Avatar';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';

function CommentComponent({ username, comment }) {
  return (
    <Box 
      sx={{ 
        display: 'flex', 
        mb: 2,
        alignItems: 'center',
      }}
    >
      <Avatar sx={{ mr: 2 }}>{username[0].toUpperCase()}</Avatar>
      <Box>
        <Typography variant="subtitle2" component="p" gutterBottom>
          {username}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          {comment}
        </Typography>
      </Box>
    </Box>
  );
}

export default CommentComponent;
