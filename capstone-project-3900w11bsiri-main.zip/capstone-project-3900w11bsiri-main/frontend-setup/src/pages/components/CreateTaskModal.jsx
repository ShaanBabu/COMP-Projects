import React, { useState } from 'react';
import { TextField, Box, Typography, Button, Modal, FormControl, InputLabel, Select, MenuItem } from '@mui/material';

// const modalStyle = {
//   position: 'absolute',
//   top: '50%',
//   left: '50%',
//   transform: 'translate(-50%, -50%)',
//   bgcolor: 'background.paper',
//   boxShadow: 24,
//   p: 4,
// };

function CreateTaskModal({ showAddTask, setShowAddTask, handleTaskCreate, projectName, projectUsers }) {
  const [newTask, setNewTask] = useState({ title: '', description: '', dueDate: '', assigned_to: [] });

  const handleInputChange = (event) => {
    setNewTask({ ...newTask, [event.target.name]: event.target.value });
  };

  const handleSubmit = () => {
    handleTaskCreate(newTask);
    setNewTask({ title: '', description: '', dueDate: '', assigned_to: [] });
  };

  const handleUserChange = (event, fieldName) => {
    setNewTask({
      ...newTask,
      [fieldName]: event.target.value,
    });
  };

  const modalStyle = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    bgcolor: 'background.paper',
    boxShadow: 24,
    p: 4,
    width: '50%',
    [`@media (max-width:600px)`]: {
      width: '90%',
    },
  };

  return (
    <Modal open={showAddTask} onClose={() => setShowAddTask(false)}>
      <Box sx={modalStyle}>
        <Typography variant="h6" component="h2" gutterBottom>
          Create Task in "{projectName}"
        </Typography>
        <Typography variant="body2" gutterBottom>
          * indicates required field
        </Typography>
        <Box sx={{ mt: 2 }}>
          <TextField
            fullWidth
            label="Title"
            name="title"
            value={newTask.title}
            onChange={handleInputChange}
            required
          />
          <TextField
            fullWidth
            label="Description"
            name="description"
            value={newTask.description}
            onChange={handleInputChange}
            sx={{ mt: 2 }}
          />
          <TextField
            fullWidth
            type="date"
            label="Due Date"
            InputLabelProps={{shrink: true}}
            name="dueDate"
            value={newTask.dueDate}
            onChange={handleInputChange}
            sx={{ mt: 2 }}
            required
          />
          <FormControl fullWidth sx={{ mt: 2 }}>
            <InputLabel id="assignee-select-label">Assign To</InputLabel>
            <Select
              labelId="assignee-select-label"
              label="Assign To"
              value={newTask?.assigned_to || []}
              onChange={(e) => handleUserChange(e, 'assigned_to')}
              multiple
            >
              {projectUsers.map((user) => (
                <MenuItem key={user} value={user}>
                  {user}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

        </Box>
        <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end' }}>
          <Button onClick={() => setShowAddTask(false)}>Cancel</Button>
          <Button variant="contained" onClick={handleSubmit} sx={{ ml: 2 }} disabled={newTask.title === '' || newTask.dueDate === ''}>
            Create
          </Button>
        </Box>
      </Box>
    </Modal>
  );
}

export default CreateTaskModal;
