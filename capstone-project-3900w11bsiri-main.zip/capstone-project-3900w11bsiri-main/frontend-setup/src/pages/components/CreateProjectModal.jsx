import React, { useState } from 'react';
import { Modal, Box, TextField, Button, Typography } from '@mui/material';

const CreateProjectModal = ({ open, handleClose, handleCreate }) => {
  const [project, setProject] = useState({
    name: '',
    description: '',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProject((prevProject) => ({
      ...prevProject,
      [name]: value,
    }));
  };

  const modalStyle = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
  };

  return (
    <Modal open={open} onClose={handleClose}>
      <Box sx={{ ...modalStyle, width: 400 }}>
        <Typography variant="h6" component="h2" gutterBottom>
          Create Project
        </Typography>
        <Box sx={{ mt: 2 }}>
          <TextField
            fullWidth
            label="Name"
            name="name"
            value={project.name}
            onChange={handleInputChange}
          />
          <TextField
            fullWidth
            label="Description"
            name="description"
            value={project.description}
            onChange={handleInputChange}
            sx={{ mt: 2 }}
          />
        </Box>
        <Box sx={{ mt: 2, display: 'flex', justifyContent: 'flex-end' }}>
          <Button onClick={handleClose}>Cancel</Button>
          <Button variant="contained" onClick={() => handleCreate(project)} sx={{ ml: 2 }}>
            Create
          </Button>
        </Box>
      </Box>
    </Modal>
  );
};

export default CreateProjectModal;
