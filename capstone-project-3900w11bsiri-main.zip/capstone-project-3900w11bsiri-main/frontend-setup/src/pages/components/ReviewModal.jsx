import React from 'react';
import { Dialog, DialogTitle, DialogContent, Typography } from '@mui/material';
import ReviewComponent from './ReviewComponent';

const ReviewModal = ({ reviews, showReviewModal, setShowReviewModal }) => {

  const handleClose = () => {
    setShowReviewModal(false);
  };

  return (
    <Dialog open={showReviewModal} onClose={handleClose}>
      <DialogTitle>Reviews</DialogTitle>
      <DialogContent>
        {reviews.length > 0 ? (
          reviews.slice().reverse().map((review, index) => (
            <ReviewComponent 
              key={index}
              reviewer={review.reviewer}
              reviewedUser={review.reviewedUsers}
              review={review.review}
              rating={review.rating}  // added this line
            />
          ))
        ) : (
          <Typography variant="body1" color="text.secondary">
            No reviews made
          </Typography>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default ReviewModal;
