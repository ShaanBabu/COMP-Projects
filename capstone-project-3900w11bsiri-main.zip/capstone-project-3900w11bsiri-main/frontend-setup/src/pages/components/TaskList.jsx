import { Button, FormControl, InputLabel, MenuItem, Modal, Select, Box, TextField } from '@mui/material';
import { useState, useEffect } from 'react';
import TaskCardComponent from './TaskCardComponent';
import { useContext } from 'react';
import { Context } from '../../context';

const TaskList = ({username = ''}) => {
  const getters = useContext(Context).getters;
  const [tasks, setTasks] = useState([]);
  const [searchOpen, setSearchOpen] = useState(false);
  const [taskNameFilter, setTaskNameFilter] = useState('');
  const [taskDescriptionFilter, setTaskDescriptionFilter] = useState('');
  const [taskDeadlineFilter, setTaskDeadlineFilter] = useState('');
  const [taskStatusFilter, setTaskStatusFilter] = useState('');
  const [taskIdFilter, setTaskIdFilter] = useState('');
  const [tasksDueInNextWeek, setTasksDueInNextWeek] = useState(0);
  const [workload, setWorkload] = useState(0);

  useEffect(() => {
    if (!getters.loggedIn) {
      return;
    }
    // Get profile information
    const getData = async () => {
      var payload
      if (username) {
        payload = {
          method: 'POST',
          headers: {
            'Content-type': 'application/json'
          },
          body: JSON.stringify({
            token: getters.token,
            username: username
          })
        }
      } else {
        payload = {
          method: 'POST',
          headers: {
            'Content-type': 'application/json'
          },
          body: JSON.stringify({
            token: getters.token
          })
        }
      }
      const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/tasklist/view`, payload).then((rawdata) => {
        return rawdata.json()
      });
      if (response.error) {
        alert(response.error);
      } else {
        console.log(response);
        setTasks(sortEarliest(response));
      }
    }
    getData();
  }, []);

  useEffect(() => {
    const oneWeekFromNow = new Date();
    oneWeekFromNow.setDate(oneWeekFromNow.getDate() + 7);

    const dueTasks = tasks.filter(task => {
        const taskDueDate = new Date(task['due_date']);
        return taskDueDate <= oneWeekFromNow && task.status !== "done";
    });

    setTasksDueInNextWeek(dueTasks.length);

    const workloadPercentage = Math.min((dueTasks.length / 20) * 100, 100);
    setWorkload(workloadPercentage);

  }, [tasks]);

  const sortEarliest = (oldTasks) => {
    const newTasks = [...oldTasks] 
    newTasks.sort((a, b) => {
      if (a['due_date'] === '') {
        return 1;
      } else if (b['due_date'] === '') {
        return -1;
      }
      const date1 = new Date(a['due_date'])
      const date2 = new Date(b['due_date'])
      if (date1 < date2) {
        return -1;
      } else if (date1 > date2) {
        return 1;
      } else return 0;
    })
    return newTasks;
  }

  const sortLatest = (oldTasks) => {
    const newTasks = [...oldTasks] 
    newTasks.sort((a, b) => {
      if (a['due_date'] === '') {
        return 1;
      } else if (b['due_date'] === '') {
        return -1;
      }
      const date1 = new Date(a['due_date'])
      const date2 = new Date(b['due_date'])
      if (date1 < date2) {
        return 1;
      } else if (date1 > date2) {
        return -1;
      } else return 0;
    })
    return newTasks;
  }

  const sortAlphabetically = (oldTasks) => {
    const newTasks = [...oldTasks] 
    newTasks.sort((a, b) => {
      if (a['name'] < b['name']) {
        return -1;
      } else if (a['name'] > b['name']) {
        return 1;
      } else return 0;
    })
    return newTasks;
  }

  return (<>
    <p>Number of tasks due in the next week: {tasksDueInNextWeek}</p>
    <p>Workload: {workload.toFixed(2)}%</p>
    <FormControl fullwidth="true">
      <InputLabel id='sort-label'>Sort tasks by</InputLabel>
      <Select
        labelId='sort-label'
        label='Sort tasks by'
        defaultValue={'1'}
        onChange={(event) => {
          switch(event.target.value) {
            case '1':
              setTasks(sortEarliest(tasks));
              break;
            case '2':
              setTasks(sortLatest(tasks));
              break;
            case '3':
              setTasks(sortAlphabetically(tasks));
              break;
            default:
          }
        }}
      >
        <MenuItem value='1'>Due Earliest</MenuItem>
        <MenuItem value='2'>Due Latest</MenuItem>
        <MenuItem value='3'>Alphabetical</MenuItem>
      </Select>
    </FormControl>
    <br /><br />
    <Button variant='contained' onClick={() => {setSearchOpen(true)}}>Search Filters</Button>
    <br /><br />
    <Modal
      open={searchOpen}
      onClose={() => {setSearchOpen(false)}}
    >
      <Box sx={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: 400,
        bgcolor: 'white',
        border: '1px solid #000',
        borderRadius: '4px',
        boxShadow: 24,
        p: 4,
      }}>
        <TextField variant='outlined' label='Filter task name' fullWidth value={taskNameFilter} onChange={(event) => {setTaskNameFilter(event.target.value)}}></TextField><br /><br />
        <TextField variant='outlined' label='Filter task description' fullWidth value={taskDescriptionFilter} onChange={(event) => {setTaskDescriptionFilter(event.target.value)}}></TextField><br /><br />
        <TextField variant='outlined' label='Filter task due date' fullWidth value={taskDeadlineFilter} onChange={(event) => {setTaskDeadlineFilter(event.target.value)}}></TextField><br /><br />
        <TextField variant='outlined' label='Filter task status' fullWidth value={taskStatusFilter} onChange={(event) => {setTaskStatusFilter(event.target.value)}}></TextField><br /><br />
        <TextField variant='outlined' label='Filter task id' fullWidth value={taskIdFilter} onChange={(event) => {setTaskIdFilter(event.target.value)}}></TextField><br /><br />
        <Button color='error' variant='contained' onClick={() => {
          setTaskNameFilter('');
          setTaskDescriptionFilter('');
          setTaskDeadlineFilter('');
          setTaskStatusFilter('');
          setTaskIdFilter('');
        }}>Clear Filters</Button>
      </Box>
    </Modal>
    {tasks.filter((task) => {
      if (taskNameFilter != '' && !task['name'].includes(taskNameFilter)) return false;
      if (taskDescriptionFilter != '' && !task['description'].includes(taskDescriptionFilter)) return false;
      if (taskDeadlineFilter != '' && !task['due_date'].includes(taskDeadlineFilter)) return false;
      if (taskStatusFilter != '' && !task['status'].includes(taskStatusFilter)) return false;
      if (taskIdFilter != '' && !task['_id'].includes(taskIdFilter)) return false;
      return true;
    }).map((task) => (
      <TaskCardComponent key={task['_id']} task={task} />
    ))}
    {tasks.filter((task) => {
      if (taskNameFilter != '' && !task['name'].includes(taskNameFilter)) return false;
      if (taskDescriptionFilter != '' && !task['description'].includes(taskDescriptionFilter)) return false;
      if (taskDeadlineFilter != '' && !task['due_date'].includes(taskDeadlineFilter)) return false;
      if (taskStatusFilter != '' && !task['status'].includes(taskStatusFilter)) return false;
      if (taskIdFilter != '' && !task['_id'].includes(taskIdFilter)) return false;
      return true;
    }).length == 0 && 'No tasks'}
  </>)
}

export default TaskList