import * as React from 'react';
import { useState, useEffect } from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import Badge from '@mui/material/Badge';
import NotificationsIcon from '@mui/icons-material/Notifications';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import MenuIcon from '@mui/icons-material/Menu';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import { ThemeProvider, useTheme } from '@mui/material/styles';
import { useNavigate, useLocation } from 'react-router-dom';
import companyLogo from '../../Pictures/logo.png';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import { useContext, Context } from '../../context';
import Typography from '@mui/material/Typography';
import { useMediaQuery } from '@mui/material';



const Navbar = ({ toggleNotifications, showNotifications }) => {
  const getters = useContext(Context).getters;
  const setters = useContext(Context).setters;
  const navigate = useNavigate();
  const location = useLocation();
  const [notificationData, setNotificationData] = useState({count: 0, notifications: []});
  const [seenCount, setSeenCount] = useState(getters.notificationsSeen);
  const [anchorEl, setAnchorEl] = useState(null);
  const [reload, setReload] = useState(false);
  let options = { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' };
  const isActive = (path) => location.pathname === path;
  const [drawerOpen, setDrawerOpen] = React.useState(false);
  const theme = useTheme();
  const matches = useMediaQuery(theme.breakpoints.down('sm'));

  const fetchNotifications = async () => {
    if (!getters.loggedIn) {
      return;
    }
    const payload = {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify({
        token: getters.token
      })
    }
    const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/notifications/get`, payload).then((rawdata) => {
      return rawdata.json();
    });
    if (response.error) {
      alert(response.error);
    } else {
      const num = response.length - seenCount;
      const data = {count: num, notifications: response.reverse()}
      setNotificationData(data);
    }
  };

  useEffect(() => {
    fetchNotifications();
    const interval = setInterval(() => {
      fetchNotifications();
    }, 5000);
    return () => clearInterval(interval);
  }, [reload]);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
    let x = notificationData.notifications.length;
    setters.setNotificationsSeen(x);
    setSeenCount(x);
    setReload(!reload); 
  };

  const list = () => (
    <List>
      {['Home', 'Projects', 'Networks'].map((text, index) => (
        <ListItem button key={text} onClick={() => {navigate(`/${text.toLowerCase()}`); setDrawerOpen(false);}}>
          <Button color={isActive(`/${text.toLowerCase()}`) ? "secondary" : "inherit"} variant={isActive(`/${text.toLowerCase()}`) ? "contained" : "text"}>
            {text}
          </Button>
        </ListItem>
      ))}
    </List>
  );

  const logout = () => {
    setters.setToken('')
    navigate('/')
  }

  return (
    <ThemeProvider theme={theme}>
      <Box sx={{ flexGrow: 1 }}>
        <AppBar position="static" color="default">
          <Toolbar>
            {matches && (
              <IconButton
                color="inherit"
                aria-label="open drawer"
                edge="start"
                onClick={() => setDrawerOpen(!drawerOpen)}
              >
                <MenuIcon />
              </IconButton>
            )}
  
            <img src={companyLogo} alt="Company Logo" style={{ height: '50px', width: '50px', marginRight: 'auto' }} />
  
            {matches ? null : (
              <>
                <Button 
                  color={isActive('/home') ? "secondary" : "inherit"} 
                  onClick={() => navigate('/home')}
                  variant={isActive('/home') ? "contained" : "text"}
                  sx={isActive('/home') ? {borderRadius: 50} : null}>
                  Home
                </Button>
                <Button 
                  color={isActive('/projects') ? "secondary" : "inherit"} 
                  onClick={() => navigate('/projects')}
                  variant={isActive('/projects') ? "contained" : "text"}
                  sx={isActive('/projects') ? {borderRadius: 50} : null}>
                  Projects
                </Button>
                <Button 
                  color={isActive('/networks') ? "secondary" : "inherit"} 
                  onClick={() => navigate('/networks')}
                  variant={isActive('/networks') ? "contained" : "text"}
                  sx={isActive('/networks') ? {borderRadius: 50} : null}>
                  Networks
                </Button>
              </>
            )}
  
            <IconButton onClick={handleClick}>
              <Badge badgeContent={notificationData.count} color="error">
                <NotificationsIcon color="secondary" />
              </Badge>
            </IconButton>
            <Menu
              id="simple-menu"
              anchorEl={anchorEl}
              keepMounted
              open={Boolean(anchorEl)}
              onClose={handleClose}
            >
            {notificationData.notifications.length > 0 && notificationData.notifications.map((n, index) => {
                let formattedDate = (new Date(n.timestamp)).toLocaleString('en-US', options);
                return (
                    <MenuItem 
                        key={index} 
                        onClick={handleClose} 
                        sx={index < notificationData.count ? {} : {backgroundColor: 'lightgray'}}
                    >
                        <Box sx={{display: 'flex', alignItems: 'center'}}>
                            <Typography variant="body2" sx={{fontSize: '0.8em', color: 'gray', mr: 1}}>{`${formattedDate}`}</Typography>
                            <Typography variant="body1">{`${n.message}`}</Typography>
                        </Box>
                    </MenuItem>
                )
            })}
            {notificationData.notifications.length === 0 && <Typography sx={{m:2}}> 
              No notifications
            </Typography>}
            </Menu>
            <Button onClick={() => navigate('/profile')} startIcon={<AccountCircleIcon color="secondary" />} sx={{textTransform: 'none'}} color='secondary'>
              <Typography>{getters.username}</Typography>
            </Button>
            <Button variant='contained' color='secondary' sx={{ml: 1}} onClick={() => logout()}>Logout</Button>
  
          </Toolbar>
        </AppBar>
  
        {matches && (
          <Drawer
            variant="temporary"
            open={drawerOpen}
            onClose={() => setDrawerOpen(false)}
          >
            {list()}
          </Drawer>
        )}
      </Box>
    </ThemeProvider>
  );
  
  
};

export default Navbar;
