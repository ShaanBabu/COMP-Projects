import React from 'react';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import companyIcon from '../Pictures/companyLogo.png';
import startImages from '../Pictures/startImages.png';
import useMediaQuery from '@mui/material/useMediaQuery';


export function Start() {
  const isSmallScreen = useMediaQuery('(max-width:600px)');


const styles = {
  root: {
    backgroundColor: '#fff',
    color: '#000',
    margin: 0,
    padding: 0,
  },
  appBar: {
    backgroundColor: '#fff',
    padding: '8px',
    textAlign: 'left',
  },
  companyIcon: {
    width: 50,
    height: 50,
  },
  navbarLinks: {
    display: 'flex',
    alignItems: 'center',
    marginLeft: 'auto',
    flexWrap: 'nowrap',
    overflowX: 'auto',
  },
  navbarLink: {
    marginRight: isSmallScreen ? '4px' : '8px', // reduce margin on small screens
    color: '#000',
    textDecoration: 'none',
    fontSize: isSmallScreen ? '12px' : '16px', // reduce font size on small screens
  },
  startButton: {
    padding: isSmallScreen ? '6px 12px' : '12px 24px', // reduce padding on small screens
    borderRadius: '4px',
    border: 'none',
    backgroundColor: '#ff9e0b',
    color: '#000',
    fontSize: isSmallScreen ? '12px' : '16px', // reduce font size on small screens
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'background-color 0.3s ease',
    '&:hover': {
      backgroundColor: '#333333',
      color: '#fff',
    },
  },
  startButtonText: {
    marginRight: '8px',
  },
  introContainer: {
    backgroundColor: '#f4edde',
    textAlign: 'center',
    padding: '24px',
  },
  introTitle: {
    fontSize: 36,
    fontWeight: 'bold',
    marginBottom: '8px',
  },
  introSubtitle: {
    fontSize: 18,
    marginBottom: '16px',
  },
  startImages: {
    backgroundColor: '#fff',
    padding: '8px',
    textAlign: 'center',
  },
  startImagesIcon: {
    width: '100%',
    height: 'auto',
  },
};

  return (
    <div style={styles.root}>
      <AppBar position="static" style={styles.appBar}>
        <Toolbar>
          <a href="/">
            <img src={companyIcon} alt="Company Logo" style={styles.companyIcon} />
          </a>
          <div style={styles.navbarLinks}>
            <a href="/about">
              <Button variant="text" style={styles.navbarLink}>
                About Us
              </Button>
            </a>
            <a href="/login">
              <Button variant="text" style={styles.navbarLink}>
                Log In
              </Button>
            </a>
            <a href="/register">
              <Button variant="contained" style={styles.startButton}>
                Get Started
              </Button>
            </a>
          </div>
        </Toolbar>
      </AppBar>
      <div style={styles.introContainer}>
        <Typography variant="h1" style={styles.introTitle}>
          Manage and Innovate
        </Typography>
        <Typography variant="body1" style={styles.introSubtitle}>
          Manage all your projects and work cohesively with your team
        </Typography>
        <a href="/register">
          <Button variant="contained" style={styles.startButton}>
            Start Now
          </Button>
        </a>
      </div>
      <div style={styles.startImages}>
        <img src={startImages} alt="Start Images" style={styles.startImagesIcon} />
      </div>
    </div>
  );
}
