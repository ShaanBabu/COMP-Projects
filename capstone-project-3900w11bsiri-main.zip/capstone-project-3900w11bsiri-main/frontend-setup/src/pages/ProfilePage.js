import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, Button, Collapse, Container, FormControlLabel, Switch, TextField, Typography, Stack, Paper, Divider, Grid } from '@mui/material';
import { useContext } from 'react';
import { Context } from '../context';
import Navbar from './components/Navbar';
import TaskList from './components/TaskList';
import { orange } from '@mui/material/colors';



export function ProfilePage() {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showPersonalInfo, setShowPersonalInfo] = useState(false);
  const [showTaskList, setShowTaskList] = useState(false)
  const [showSettings, setShowSettings] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [title, setTitle] = useState('');
  const [birthday, setBirthday] = useState('');
  const [visibility, setVisibility] = useState(true);
  const getters = useContext(Context).getters;
  const navigate = useNavigate();
  const [userInfo, setUserInfo] = useState({})
  const [notificationSettings, setNotificationSettings] = useState({
    'on_friend_request': true,
    'on_friend_accept': true,
    'on_project_invite': true,
    'on_assignment': true,
    'on_ping': true,
    'on_deadline7': true,
    'on_deadline3': true,
    'on_deadline1': true,
  });
  
  const toggleNotifications = () => {
    setShowNotifications(!showNotifications);
  };

  const togglePersonalInfo = () => {
    setShowPersonalInfo(!showPersonalInfo);
  };

  const toggleSettings = () => {
    setShowSettings(!showSettings);
  };

  const handleNameChange = (event) => {
    setName(event.target.value);
  };

  const handleDescriptionChange = (event) => {
    setDescription(event.target.value);
  };

  const handleTitleChange = (event) => {
    setTitle(event.target.value);
  };

  const handleBirthdayChange = (event) => {
    setBirthday(event.target.value);
  };

  const handleVisibilityToggle = async () => {
    const payload = {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify({
        token: getters.token,
        visible: !visibility
      })
    }
    const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/profile/visible`, payload).then((rawdata) => {
      return rawdata.json();
    });
    if (response.error) {
      alert(response.error);
    } else {
      setVisibility(!visibility);
    }
  };

  const handleToggleChange = (event, label) => {
    // Calculate new state
    const newNotificationSettings = {
      ...notificationSettings,
      [label]: event.target.checked
    };
  
    const payload = {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify({
        token: getters.token,
        notification_settings: newNotificationSettings
      })
    }
  
    fetch(`${process.env.REACT_APP_BACKEND_SERVER}/notifications/set`, payload)
      .then((rawdata) => rawdata.json())
      .then(response => {
        if (response.error) {
          alert(response.error);
        }
      });
  
    // Update state after sending the request
    setNotificationSettings(newNotificationSettings);
  };  

  useEffect(() => {
    if (!getters.loggedIn) {
      navigate('/');
      return;
    }
    // Get profile information
    const getData = async () => {
      const payload = {
        method: 'POST',
        headers: {
          'Content-type': 'application/json'
        },
        body: JSON.stringify({
          token: getters.token
        })
      }
      const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/profile/display`, payload).then((rawdata) => {
        return rawdata.json();
      });
      if (response.error) {
        alert(response.error);
      } else {
        setUserInfo(response);
        setName(response['name']);
        setDescription(response['description']);
        setBirthday(response['birthday']);
        setTitle(response['title']);
        setVisibility(response['visible']);
      }
    }
    getData();
  }, []);

  const handleConfirmChanges = async () => {
    const payload = {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        token: getters.token,
        name: name,
        description: description,
        title: title,
        birthday: birthday,
      })
    }
    const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/profile/edit`, payload).then((rawdata) => {
      return rawdata.json();
    });
    if (response.error) {
      alert(response.error);
    } else {
      const newUserData = {
        ...userInfo,
        name: name,
        description: description,
        title: title,
        birthday: birthday
      };
      setUserInfo(newUserData);
    }
  };

  return (
    <div>
      <Navbar toggleNotifications={toggleNotifications} showNotifications={showNotifications} />
      <Container>
        <Box sx={{ mt: 5 }}>
          <Typography variant="h4" component="h1" gutterBottom align="center">
            {name}'s Profile
          </Typography>
          <Divider />
        </Box>

        <Grid container spacing={3} sx={{ mt: 5 }}>
          <Grid item xs={12} md={4}>
            <Paper elevation={3} sx={{ p: 3 }}>
              <Button variant="contained" color="primary" onClick={togglePersonalInfo} fullWidth sx={{ mb: 2 }}>
                Personal Info
              </Button>
              <Collapse in={showPersonalInfo}>
                <Typography variant="h5" gutterBottom>
                  Personal Info
                </Typography>
                <Box component="form" noValidate>
                  <TextField variant="outlined" margin="normal" fullWidth id="name" label="Name" value={name} onChange={handleNameChange} />
                  <TextField variant="outlined" margin="normal" fullWidth id="description" label="Description" value={description} onChange={handleDescriptionChange} />
                  <TextField variant="outlined" margin="normal" fullWidth id="title" label="Title" value={title} onChange={handleTitleChange} />
                  <TextField
                    variant="outlined"
                    margin="normal"
                    fullWidth
                    id="birthday"
                    label="Birthday"
                    type="date"
                    value={birthday}
                    onChange={handleBirthdayChange}
                    InputLabelProps={{
                      shrink: true,
                    }}
                  />
                  <Button 
                    variant="contained" 
                    onClick={handleConfirmChanges}  
                    sx={{ mb: 2, bgcolor: orange[500], width: '80%', ml: '10%'}}
                    disabled={!(
                      userInfo['name'] !== name ||
                      userInfo['description'] !== description ||
                      userInfo['title'] !== title ||
                      userInfo['birthday'] !== birthday)}
                  >
                    Confirm Changes
                  </Button>
                </Box>
              </Collapse>
            </Paper>
          </Grid>

          <Grid item xs={12} md={4}>
            <Paper elevation={3} sx={{ p: 3 }}>
              <Button variant="contained" color="primary" onClick={toggleSettings} fullWidth sx={{ mb: 2 }}>
                Settings
              </Button>
              <Collapse in={showSettings}>
                <Typography variant="h5" gutterBottom>
                  Settings
                </Typography>
                <Stack spacing={3}>
                  <FormControlLabel control={<Switch checked={visibility} onChange={handleVisibilityToggle} color="primary" />} label="Visibility" />
                  {visibility ? <span>Visible to others</span> : <span>Hidden from others</span>}
                  <Typography variant="h5" gutterBottom>
                    Notifications
                  </Typography>
                  {
                    [{setting: 'on_friend_request', label: 'on friend request'}, {setting: 'on_friend_accept', label: 'on friend accept'}, {setting: 'on_project_invite', label: 'on project invite'},
                    {setting: 'on_assignment', label: 'on task assignment'}, {setting: 'on_ping', label: 'on ping'}, {setting: 'on_deadline7', label: '7 days before task deadline'},
                    {setting: 'on_deadline3', label: '3 days before task deadline'}, {setting: 'on_deadline1', label: '1 day before task deadline'}].map((obj) => {
                      return (
                        <div key={obj['setting']}>
                          <FormControlLabel 
                            control={
                              <Switch 
                                checked={notificationSettings[obj['setting']]} 
                                onChange={(event) => handleToggleChange(event, obj['setting'])} 
                                color="primary" 
                              />} 
                            label={obj['label']}  // Use the formatted labelText
                          />
                          {notificationSettings[obj['setting']] ? <span>Enabled</span> : <span>Disabled</span>}
                        </div>
                      );
                    })
                  }
                </Stack>
              </Collapse>
            </Paper>
          </Grid>


          <Grid item xs={12} md={4}>
            <Paper elevation={3} sx={{ p: 3 }}>
              <Button variant="contained" color="primary" onClick={() => {setShowTaskList(!showTaskList)}} fullWidth sx={{ mb: 2 }}>
                Task List
              </Button>
              <Collapse in={showTaskList}>
                <Typography variant="h5" gutterBottom>
                  Task List
                </Typography>
                <TaskList />
              </Collapse>
            </Paper>
          </Grid>
        </Grid>
      </Container>
    </div>
  );
}