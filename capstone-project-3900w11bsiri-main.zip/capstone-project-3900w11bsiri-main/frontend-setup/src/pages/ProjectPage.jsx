import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useContext, Context } from '../context';
import CreateProjectModal from './components/CreateProjectModal';
import ProjectComponent from './components/ProjectComponent';
import { Button, Container, Typography, List, ListItem, ListItemText, Divider, Box, Grid } from '@mui/material';
import Navbar from './components/Navbar';


export function ProjectPage() {
  const getters = useContext(Context).getters;
  const navigate = useNavigate();
  const [showCreateProject, setShowCreateProject] = useState(false);
  const [selectedProject, setSelectedProject] = useState(null);
  const [showNotifications, setShowNotifications] = useState(false);
  const [projects, setProjects] = useState([]);
  const [projectCounter, setProjectCounter] = useState(0);


  useEffect(() => {
    if (!getters.loggedIn) {
      navigate('/');
      return;
    }
    // Get projects information
    const getData = async () => {
      const payload = {
        method: 'POST',
        headers: {
          'Content-type': 'application/json'
        },
        body: JSON.stringify({
          token: getters.token
        })
      }
      const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/project/display`, payload).then((rawdata) => {
        return rawdata.json();
      });
      if (response.error) {
        alert(response.error);
      } else {
        setProjects(response);
        if (selectedProject !== null) {
          setSelectedProject(response.filter((project) => {return project._id === selectedProject._id})[0])
        }
      }
    }
    getData();
    const interval = setInterval(() => {
      getData();
    }, 5000);
    return () => clearInterval(interval);
  }, [projectCounter]);

  const getProjectStyle = (projectId) => {
    return (selectedProject != null && projectId === selectedProject._id) ? { borderRadius: "5px", backgroundColor: "#FFA500", padding: "5px" } : {};
  };

  const handleCreateProjectClick = () => {
    setShowCreateProject(true);
  };

  const handleProjectSelect = (project) => {
    setSelectedProject(project);
  };

  const toggleNotifications = () => {
    setShowNotifications(!showNotifications);
  };

  const handleProjectCreate = async (newProject) => {
    const payload = {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify({
        token: getters.token,
        name: newProject['name'],
        description: newProject['description'],
        admins: [getters.username],
        users: [getters.username],
        tasks: []
      })
    }
    const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/project/create`, payload).then((rawdata) => {
      return rawdata.json();
    });
    if (response.error) {
      alert(response.error);
    } else {
      newProject._id = response._id;
      newProject['creator'] = getters.username;
      newProject['admins'] = [getters.username];
      newProject['users'] = [getters.username];
      newProject['viewers'] = [getters.username];
      newProject['tasks'] = [];
      setProjects((prevProjects) => [...prevProjects, newProject]);
      setShowCreateProject(false);
    }
  };

  const handleProjectDelete = async (project) => {
    const payload = {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify({
        token: getters.token,
        projectID: project._id
      })
    }
    const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/project/remove`, payload).then((rawdata) => {
      return rawdata.json();
    });
    if (response.error) {
      alert(response.error);
    } else {
      setProjectCounter(prevCount => prevCount + 1);
      setSelectedProject(null)
    }
  };

  const handleProjectLeave = async (project) => {
    const payload = {
      method: 'POST',
      headers: {
        'Content-type': 'application/json'
      },
      body: JSON.stringify({
        token: getters.token,
        projectID: project._id
      })
    }
    const response = await fetch(`${process.env.REACT_APP_BACKEND_SERVER}/project/leave`, payload).then((rawdata) => {
      return rawdata.json();
    });
    if (response.error) {
      alert(response.error);
    } else {
      setProjectCounter(prevCount => prevCount + 1);
      setSelectedProject(null)
    }
  }

  return (
    <>
      <Navbar toggleNotifications={toggleNotifications} showNotifications={showNotifications} />
      <Container>
        <Box sx={{ mt: 10 }}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={3}>
              <Box>
                <Typography variant="h4" component="h1" gutterBottom>
                  My Projects
                </Typography>
                <Box sx={{ mt: 1 }}>
                  <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
                    <Divider sx={{ width: '50%', borderTop: '5px solid orange', mb: 1, mt: 0 }} />
                    <List>
                      {projects.map((project) => (
                        <ListItem
                          key={project._id}
                          onClick={() => handleProjectSelect(project)}
                          sx={{ mb: 1 }}
                        >
                          <ListItemText primary={project.name} sx={{ ...getProjectStyle(project._id) }} />
                        </ListItem>
                      ))}
                    </List>
                  </Box>
                </Box>
                <Grid container spacing={2} sx={{ mt: 0 }}>
                  <Grid item xs={12}>
                    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
                      <Button variant="contained" onClick={handleCreateProjectClick} sx = {{ backgroundColor: 'orange', mt: -2 }}>
                        Create Project
                      </Button>
                    </Box>
                  </Grid>
                </Grid>
              </Box>
            </Grid>
  
            {selectedProject && 
              <Grid item xs={12} sm={9}>
                <ProjectComponent 
                  project={selectedProject} 
                  updateProject={setSelectedProject}
                  handleProjectDelete={handleProjectDelete}
                  handleProjectLeave={handleProjectLeave}
                  refreshProjects={() => setProjectCounter(prevCount => prevCount + 1)}
                />
              </Grid>
            }
          </Grid>
        </Box>
      </Container>
  
      {showCreateProject && (
      <CreateProjectModal 
        open={showCreateProject} 
        handleClose={() => setShowCreateProject(false)} 
        handleCreate={handleProjectCreate} 
      />
      )}
    </>
  );
}

export default ProjectPage;