import React, { createContext } from 'react';

export const initialValue = {
  loggedIn: false,
  token: null,
  username: '',
  notificationsSeen: 0,
};

export const Context = createContext(initialValue);
export const useContext = React.useContext;
